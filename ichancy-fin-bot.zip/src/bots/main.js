// بوت العملاء: القوائم، إنشاء الحساب، الشحن، السحب، الإهداء، الدعم، السجل.
import { Telegraf, Markup } from 'telegraf';
import * as state from './state.js';
import { mainMenu, backRow, depositMethods, withdrawMethods, txSubmittedRow, historyKeyboards } from './keyboards.js';
import { getSecret } from '../services/vault.js';
import { upsertUser, getUser, attachIChancy, readIChancyPassword } from '../services/users.js';
import * as payments from '../services/payments.js';
import * as withdrawals from '../services/withdrawals.js';
import * as gifts from '../services/gifts.js';
import * as settings from '../services/settings.js';
import { createAccount } from '../integrations/ichancy/index.js';
import { AppError } from '../services/errors.js';
import { formatMinor, normalizeDigits, toMinor, SHOP_CURRENCY, InputError } from '../utils/money.js';
import { esc, code, bold } from '../utils/html.js';
import { requestId } from '../utils/ids.js';
import { nowIso } from '../utils/time.js';
import { all, run } from '../db/index.js';
import { notifyAdmins, isAdmin } from '../services/notify.js';
import { audit } from '../services/audit.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('bot:main');

/** يلفّ كل هاندلر حتى ما يطير البوت بسبب استثناء. */
function safe(fn) {
  return async (ctx, ...rest) => {
    try {
      await fn(ctx, ...rest);
    } catch (err) {
      const msg = err instanceof AppError ? err.message : 'صار خطأ غير متوقع، حاول تاني بعد شوي.';
      log.error('handler failed', { err: String(err.message), stack: err?.stack });
      try {
        await ctx.reply(`⚠️ ${esc(msg)}`, { parse_mode: 'HTML' });
      } catch { /* المستخدم مايرد — ما في شي نعمله */ }
    }
  };
}

const NO_BALANCE = 'لا يوجد لديك رصيد كافي للقيام بعملية السحب';

function welcomeText(user) {
  const shop = settings.publicSettings();
  const lines = [
    bold(`أهلاً ${esc(user.full_name || user.username || 'بك')} 👋`),
    '',
    `💰 رصيدك: ${bold(formatMinor(user.balance, SHOP_CURRENCY))}`,
    user.ichancy_username ? `🎮 حسابك على آيسانسي: ${code(user.ichancy_username)}` : '',
    '',
    'اختر من القائمة:',
  ].filter(Boolean);
  void shop;
  return lines.join('\n');
}

async function showMenu(ctx) {
  const user = upsertUser(ctx.from);
  await ctx.reply(welcomeText(user), { parse_mode: 'HTML', ...mainMenu() });
}

/* ---------------------------------------------------------------- الحساب */

async function startIChancy(ctx) {
  const user = getUser(ctx.from.id);

  if (user?.ichancy_username) {
    await ctx.reply(
      [
        'أنت مسجّل مسبقاً.',
        '',
        `🎮 اليوزرنيم: ${code(user.ichancy_username)}`,
        `📧 الإيميل: ${code(user.ichancy_email)}`,
      ].join('\n'),
      { parse_mode: 'HTML', ...existingAccountKeyboard() },
    );
    return;
  }

  state.set(ctx.from.id, 'ichancy:name', {});
  await ctx.reply(
    'اكتب اسم المستخدم اللي بدك إياه على آيسانسي.\n\n' +
      'رح نضيف إله تذييل عشوائي تلقائياً لضمان التفرد، ونولّد إيميل وكلمة سر قوية.',
    { parse_mode: 'HTML' },
  );
}

function existingAccountKeyboard() {
  return Markup.inlineKeyboard([
    ['🔑 إرسال كلمة السر', 'ic:password'],
    ['⬅️ القائمة', 'nav:menu'],
  ]).resize();
}

async function handleIChancyName(ctx) {
  const name = String(ctx.message.text || '').trim();
  if (name.length < 3) throw new InputError('اسم المستخدم قصير جداً (3 حروف على الأقل)');

  const thinking = await ctx.reply('⏳ عم أنشئ حسابك على آيسانسي…');

  const created = await createAccount({ desiredName: name, telegramId: ctx.from.id });
  attachIChancy(ctx.from.id, created);

  state.clear(ctx.from.id);
  await ctx.telegram.editMessageText(thinking.message_id, '✅ تم الإنشاء').catch(() => {});

  await ctx.reply(
    [
      '🎉 <b>تم إنشاء حسابك على آيسانسي</b>',
      '',
      `👤 اليوزرنيم: ${code(created.username)}`,
      `📧 الإيميل: ${code(created.email)}`,
      `🔑 كلمة السر: ${code(created.password)}`,
      '',
      '⚠️ احفظهم الحين — كلمة السر مش رح تظهر تاني إلا إذا طلبتها من القائمة.',
    ].join('\n'),
    { parse_mode: 'HTML', ...backRow() },
  );
}

/* -------------------------------------------------------------- الإيداع */

async function startDeposit(ctx) {
  state.set(ctx.from.id, 'dp:method', {});
  await ctx.reply('اختر طريقة الدفع:', { ...depositMethods() });
}

async function depositMethodChosen(ctx, methodId) {
  const method = settings.paymentMethod(methodId);
  if (!method) throw new InputError('طريقة الدفع غير متاحة');

  state.set(ctx.from.id, 'dp:amount', { methodId });
  const where = method.number || method.account || '—';
  await ctx.reply(
    [
      `💰 <b>${esc(method.label)}</b>`,
      `حوّل المبلغ إلى: ${code(where)}`,
      method.network ? `الشبكة: ${code(method.network)}` : '',
      '',
      'الآن اكتب المبلغ الذي حوّلته.',
    ].filter(Boolean).join('\n'),
    { parse_mode: 'HTML' },
  );
}

async function depositAmountGiven(ctx) {
  const cur = state.get(ctx.from.id);
  const methodId = cur.data.methodId;
  const method = settings.paymentMethod(methodId);
  if (!method) throw new InputError('طريقة الدفع غير متاحة');

  const currency = (method.currency || 'SYP').toUpperCase();
  const amount = toMinor(ctx.message.text, currency);
  const dep = payments.createIntent(ctx.from.id, methodId, amount);

  state.set(ctx.from.id, 'dp:tx', { depId: dep.id });
  const credited = formatMinor(dep.credited_amount ?? dep.amount, SHOP_CURRENCY);
  const bonusPct = Number(settings.get('bonus.deposit_pct', 0)) || 0;

  await ctx.reply(
    [
      '✅ <b>طلب الإيداع جاهز</b>',
      '',
      `المبلغ: ${bold(formatMinor(dep.amount, currency))}`,
      `رصيدك بعد الشحن: ${bold(credited)}${bonusPct ? ` (+${bonusPct}% بونص)` : ''}`,
      `رقم طلبك: ${code(dep.id)}`,
      '',
      'لما تخلّص التحويل، ابعثلنا <b>رقم العملية</b> وهنتحقق ونشحنك لحظياً.',
      `الطلب صالح لـ ${Number(settings.get('deposit.expires_hours', 12))} ساعة.`,
    ].join('\n'),
    { parse_mode: 'HTML', ...txSubmittedRow(dep.id) },
  );
}

async function depositTxGiven(ctx) {
  const cur = state.get(ctx.from.id);
  const dep = payments.submitTx(cur.data.depId, ctx.message.text);
  state.set(ctx.from.id, 'dp:tx', { depId: dep.id });

  const row = all(
    `SELECT * FROM payment_events WHERE tx_id = ? AND status = 'matched' ORDER BY created_at DESC LIMIT 1`,
    dep.tx_id,
  )[0];

  if (row) {
    state.clear(ctx.from.id);
    await ctx.reply('✅ لقينا حوالتك وشحنّا رصيدك. تأكد من الرصيد تحت 👇', { ...mainMenu() });
  } else {
    await ctx.reply(
      `📨 سجّلنا رقم العملية ${code(dep.tx_id)}.\nلما توصل الحوالة بنتحقق آلياً ونشحن رصيدك.`,
      { parse_mode: 'HTML', ...txSubmittedRow(dep.id) },
  );
  }
}

async function depositCheck(ctx, depId) {
  const dep = payments.getDeposit(depId);
  if (!dep) throw new InputError('الطلب مو موجود');

  if (dep.status === 'verified') {
    state.clear(ctx.from.id);
    const user = getUser(ctx.from.id);
    await ctx.reply(
      `✅ تم شحن ${bold(formatMinor(dep.credited_amount ?? dep.amount, SHOP_CURRENCY))}.\nرصيدك الآن: ${bold(formatMinor(user.balance, SHOP_CURRENCY))}`,
      { parse_mode: 'HTML', ...mainMenu() },
    );
    return;
  }
  if (dep.status === 'pending') {
    await ctx.reply('⏳ الحوالة ما وصلت بعد. بنتحقق آلياً لحظة ما توصل — ما في داعي تسأل كل شوي.');
    return;
  }
  await ctx.reply(`❌ الطلب بحالة: ${esc(dep.status)}. ابدأ طلب جديد من القائمة.`, { ...mainMenu() });
}

/* ----------------------------------------------------------------- السحب */

async function startWithdraw(ctx) {
  const user = getUser(ctx.from.id);
  if (!user || user.balance <= 0) {
    await ctx.reply(`💸 ${NO_BALANCE}`);
    return;
  }
  state.set(ctx.from.id, 'wd:method', {});
  await ctx.reply(
    `رصيدك الحالي: ${bold(formatMinor(user.balance, SHOP_CURRENCY))}\n\nاختر طريقة السحب:`,
    { parse_mode: 'HTML', ...withdrawMethods() },
  );
}

async function withdrawMethodChosen(ctx, methodId) {
  const method = settings.paymentMethod(methodId);
  if (!method) throw new InputError('طريقة السحب غير متاحة');
  state.set(ctx.from.id, 'wd:account', { methodId });
  await ctx.reply(
    method.kind === 'bank'
      ? 'ابعث رقم الحساب (IBAN أو رقم الحساب):'
      : 'ابعث رقم المحفظة/الحساب اللي بدك تصرّف عليه:',
  );
}

async function withdrawAccountGiven(ctx) {
  const cur = state.get(ctx.from.id);
  const account = String(ctx.message.text || '').trim();
  if (account.length < 4) throw new InputError('رقم الحساب غير صالح');
  state.set(ctx.from.id, 'wd:amount', { methodId: cur.data.methodId, account });
  await ctx.reply('اكتب المبلغ المطلوب سحبه:');
}

async function withdrawAmountGiven(ctx) {
  const cur = state.get(ctx.from.id);
  const { methodId, account } = cur.data;
  const w = withdrawals.request(ctx.from.id, {
    methodId,
    account,
    amount: ctx.message.text,
  });

  state.clear(ctx.from.id);
  const user = getUser(ctx.from.id);

  await ctx.reply(
    [
      '🧾 <b>تم استلام طلب السحب</b>',
      '',
      `المبلغ: ${bold(formatMinor(w.amount))}`,
      `العمولة: ${formatMinor(w.fee)}`,
      `الصافي لك: ${bold(formatMinor(w.net_amount))}`,
      `الحساب: ${code(w.account)}`,
      `رصيدك بعد الحجز: ${formatMinor(user.balance, SHOP_CURRENCY)}`,
      '',
      'رح يتواصل معك الأدمن لتأكيد التحويل. إذا انرفض الطلب، المبلغ بيرجع لرصيدك تلقائياً.',
    ].join('\n'),
    { parse_mode: 'HTML', ...backRow() },
  );
}

/* ----------------------------------------------------------------- الإهداء */

async function startGift(ctx) {
  state.set(ctx.from.id, 'gf:to', {});
  await ctx.reply('ابعث رقم آيدي (ID) تيليغرام للصديق اللي بدك تهدّيله، أو كود الجائزة:');
}

async function giftRecipientGiven(ctx) {
  const raw = String(normalizeDigits(ctx.message.text)).trim();
  state.set(ctx.from.id, 'gf:amount', { to: raw });
  await ctx.reply('اكتب المبلغ:');
}

async function giftAmountGiven(ctx) {
  const cur = state.get(ctx.from.id);
  const to = cur.data.to;
  const out = gifts.sendToId(ctx.from.id, to, ctx.message.text);
  state.clear(ctx.from.id);

  const you = getUser(ctx.from.id);
  await ctx.reply(
    [
      '🎁 <b>تم الإهداء بنجاح</b>',
      '',
      `المبلغ: ${bold(formatMinor(out.amount))}`,
      `المستلم: ${code(out.to)}`,
      `رصيدك الآن: ${formatMinor(you.balance, SHOP_CURRENCY)}`,
    ].join('\n'),
    { parse_mode: 'HTML', ...mainMenu() },
  );
}

/* -------------------------------------------------------------- الدعم والسجل */

async function startSupport(ctx) {
  state.set(ctx.from.id, 'sp:msg', {});
  await ctx.reply('اكتب رسالتك لفريق الدعم، رح يوصلهم فوراً:');
}

async function supportMessageGiven(ctx) {
  const message = String(ctx.message.text || '').trim();
  if (message.length < 3) throw new InputError('الرسالة قصيرة جداً');

  const id = requestId('sp');
  run(
    `INSERT INTO support_tickets (id, user_id, message, created_at) VALUES (?, ?, ?, ?)`,
    id, ctx.from.id, message, nowIso(),
  );
  state.clear(ctx.from.id);
  audit({ actor: `user:${ctx.from.id}`, action: 'support.new', target: id });

  await notifyAdmins(
    `🆘 <b>رسالة دعم جديدة</b>\nمن: ${code(ctx.from.id)}\n\n${esc(message)}`,
    { kind: 'support', ticketId: id },
  );

  await ctx.reply('✅ وصلتنا رسالتك، رح نرد عليك بأقرب وقت.', { ...mainMenu() });
}

async function showHistory(ctx) {
  const rows = payments.recentForUser(ctx.from.id, 5);
  const user = getUser(ctx.from.id);

  const KIND = { deposit: '💰 إيداع', withdrawal: '🏧 سحب', gift_out: '🎁 إهداء' };
  const STATUS = {
    verified: '✅ مكتمل', approved: '✅ مكتمل', rejected: '❌ مرفوض',
    expired: '⌛ انتهت', completed: '✅ مكتمل',
  };

  const lines = rows.length
    ? rows.map((r, i) => {
      const d = new Date(r.created_at).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });
      return `${i + 1}. ${KIND[r.kind] || r.kind} — ${formatMinor(r.amount, r.currency || SHOP_CURRENCY)} [${STATUS[r.status] || r.status}]\n   ${d}`;
    })
    : ['لسا ما في أي عملية.'];

  await ctx.reply(
    [`📜 <b>آخر ${rows.length} عمليات</b>`, '', ...lines, '', `💰 رصيدك: ${bold(formatMinor(user.balance, SHOP_CURRENCY))}`].join('\n'),
    { parse_mode: 'HTML', ...historyKeyboards() },
  );
}

/* ------------------------------------------------------------------ التركيب */

const TEXT_ROUTES = {
  'ichancy:name': handleIChancyName,
  'dp:amount': depositAmountGiven,
  'dp:tx': depositTxGiven,
  'wd:account': withdrawAccountGiven,
  'wd:amount': withdrawAmountGiven,
  'gf:to': giftRecipientGiven,
  'gf:amount': giftAmountGiven,
  'sp:msg': supportMessageGiven,
};

export function createMainBot() {
  const token = getSecret('main_bot_token');
  if (!token) {
    log.warn('main_bot_token غير مضبوط — بوت العملاء مش شغّال');
    return null;
  }

  const bot = new Telegraf(token);

  bot.start(safe((ctx) => showMenu(ctx)));
  bot.help(safe((ctx) => showMenu(ctx)));

  bot.action(/^nav:menu$/, safe((ctx) => showMenu(ctx)));
  bot.action(/^nav:ichancy$/, safe((ctx) => startIChancy(ctx)));
  bot.action(/^nav:deposit$/, safe((ctx) => startDeposit(ctx)));
  bot.action(/^nav:withdraw$/, safe((ctx) => startWithdraw(ctx)));
  bot.action(/^nav:gift$/, safe((ctx) => startGift(ctx)));
  bot.action(/^nav:support$/, safe((ctx) => startSupport(ctx)));
  bot.action(/^nav:history$/, safe((ctx) => showHistory(ctx)));

  bot.action(/^ic:password$/, safe(async (ctx) => {
    const pass = readIChancyPassword(ctx.from.id);
    await ctx.reply(
      pass ? `🔑 كلمة السر: ${code(pass)}` : 'ما في حساب محفوظ عندك.',
      { parse_mode: 'HTML', ...backRow() },
    );
  }));

  bot.action(/^dp:method:(.+)$/, safe((ctx) => depositMethodChosen(ctx, ctx.match[1])));
  bot.action(/^dp:check:(.+)$/, safe((ctx) => depositCheck(ctx, ctx.match[1])));

  bot.action(/^wd:method:(.+)$/, safe((ctx) => withdrawMethodChosen(ctx, ctx.match[1])));

  bot.on('text', safe(async (ctx) => {
    const cur = state.get(ctx.from.id);
    const handler = TEXT_ROUTES[cur.state];
    if (!handler) {
      await showMenu(ctx);
      return;
    }
    if (isAdmin(ctx.from.id)) {
      await ctx.reply('أنت أدمن — استخدم بوت الأدمن أو اللوحة.');
      return;
    }
    await handler(ctx);
  }));

  bot.catch((err) => log.error('telegraf main', { err: String(err) }));
  return bot;
}

export { showMenu };
