// حالة المستخدم داخل البوت (state machine) — مخزّنة بالقاعدة عشان ما تضيع
// إذا انقطع الاتصال أو أُعيد تشغيل الخادم.
import { one, run } from '../db/index.js';
import { nowIso, isExpired, MINUTE } from '../utils/time.js';

const TTL = 15 * MINUTE;

export function get(userId) {
  const row = one('SELECT * FROM user_state WHERE user_id = ?', Number(userId));
  if (!row?.state) return { state: null, data: {} };
  if (isExpired(row.updated_at)) {
    clear(userId);
    return { state: null, data: {} };
  }
  let data = {};
  try {
    data = row.data ? JSON.parse(row.data) : {};
  } catch {
    data = {};
  }
  return { state: row.state, data };
}

export function set(userId, state, data = {}) {
  run(
    `INSERT INTO user_state (user_id, state, data, updated_at) VALUES (?, ?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET state = excluded.state, data = excluded.data, updated_at = excluded.updated_at`,
    Number(userId), state, JSON.stringify(data), nowIso(),
  );
}

export function patch(userId, data) {
  const cur = get(userId);
  set(userId, cur.state, { ...cur.data, ...data });
}

export function clear(userId) {
  run('DELETE FROM user_state WHERE user_id = ?', Number(userId));
}

export const isIdle = (userId) => get(userId).state === null;
