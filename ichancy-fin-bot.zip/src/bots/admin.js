// بوت الأدمن: موافقات السحب، مراجعة الحوالات، تعديل الأرصدة، بث، وإحصاءات.
import { Telegraf, Markup } from 'telegraf';
import { getSecret } from '../services/vault.js';
import { config } from '../config.js';
import { isAdmin, registerSender } from '../services/notify.js';
import * as withdrawals from '../services/withdrawals.js';
import * as payments from '../services/payments.js';
import * as users from '../services/users.js';
import * as ledger from '../services/ledger.js';
import * as settings from '../services/settings.js';
import { audit } from '../services/audit.js';
import { all, one } from '../db/index.js';
import { formatMinor, toMinor, SHOP_CURRENCY, InputError } from '../utils/money.js';
import { esc, code, bold } from '../utils/html.js';
import { AppError } from '../services/errors.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('bot:admin');

function panelUrl() {
  return config.publicUrl ? `${config.publicUrl}/` : `http://localhost:${config.port}/`;
}

function safe(fn) {
  return async (ctx, ...rest) => {
    try {
      await fn(ctx, ...rest);
    } catch (err) {
      const msg = err instanceof AppError ? err.message : 'صار خطأ غير متوقع.';
      log.error('admin handler failed', { err: String(err.message) });
      await ctx.reply(`⚠️ ${esc(msg)}`).catch(() => {});
    }
  };
}

function withdrawalCard(w) {
  return [
    `🏧 <b>طلب سحب</b> ${code(w.id)}`,
    `المستخدم: ${code(w.user_id)}${w.username ? ` (@${esc(w.username)})` : ''}`,
    `الطريقة: ${esc(w.method)}`,
    `الحساب: ${code(w.account)}`,
    `المبلغ: ${bold(formatMinor(w.amount))} | العمولة: ${formatMinor(w.fee)} | الصافي: ${bold(formatMinor(w.net_amount))}`,
  ].join('\n');
}

async function sendPendingWithdrawals(ctx) {
  const { rows } = withdrawals.listWithdrawals({ status: 'pending', limit: 10 });
  if (!rows.length) {
    await ctx.reply('✅ ما في طلبات سحب معلّقة.');
    return;
  }
  for (const w of rows) {
    await ctx.reply(withdrawalCard(w), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        ['✅ تأكيد', `w:ok:${w.id}`],
        ['❌ رفض (يرجع المبلغ)', `w:no:${w.id}`],
      ]).resize(),
    });
  }
}

async function sendOrphans(ctx) {
  const rows = all(
    `SELECT * FROM payment_events WHERE status IN ('unmatched','invalid') ORDER BY created_at DESC LIMIT 10`,
  );
  if (!rows.length) {
    await ctx.reply('✅ ما في حوالات معلّقة.');
    return;
  }
  for (const e of rows) {
    await ctx.reply(
      [
        '⚠️ <b>حوالة ما انطابقت</b>',
        `رقم العملية: ${code(e.tx_id || '—')}`,
        `المبلغ: ${e.amount ?? '—'} ${esc(e.currency || '')}`,
        `السبب: ${esc(e.reason || '')}`,
        `الوقت: ${new Date(e.created_at).toLocaleString('ar-EG')}`,
      ].join('\n'),
      { parse_mode: 'HTML' },
    );
  }
  const pend = payments.listDeposits({ status: 'pending', limit: 10 }).rows;
  if (pend.length) {
    for (const d of pend) {
      await ctx.reply(
        `⏳ طلب إيداع ${code(d.id)}\nالمستخدم: ${code(d.user_id)}\nرقم العملية: ${code(d.tx_id || '—')}\nالمبلغ: ${formatMinor(d.amount, d.currency)}`,
        {
          parse_mode: 'HTML',
          ...Markup.inlineKeyboard([
            ['✅ شحن يدوي', `d:ok:${d.id}`],
            ['❌ رفض', `d:no:${d.id}`],
          ]).resize(),
        },
      );
    }
  }
}

async function sendStats(ctx) {
  const u = users.stats();
  const d = payments.depositStats();
  const w = withdrawals.withdrawStats();
  const flow = ledger.totalFlow();

  await ctx.reply(
    [
      '📊 <b>ملخّص</b>',
      '',
      `👥 مستخدمين: ${u.users} (حسابات آيسانسي: ${u.accounts}, موقوفين: ${u.blocked})`,
      `💰 إجمالي الأرصدة: ${formatMinor(u.liabilities)}`,
      '',
      `💳 إيداعات — ✅ ${d.verified} | ⏳ ${d.pending} | ❌ ${d.rejected} | ⌛ ${d.expired}`,
      `🏧 سحوبات — ⏳ ${w.pending} | ✅ ${w.approved} | ❌ ${w.rejected}`,
      `🧾 العمولات المحصّلة: ${formatMinor(w.fees)}`,
      '',
      `📥 إجمالي الشحن: ${formatMinor(flow.deposits)}`,
      `📤 إجمالي السحب: ${formatMinor(flow.withdrawals)}`,
      `🎁 إجمالي البونص: ${formatMinor(flow.bonuses)}`,
    ].join('\n'),
    { parse_mode: 'HTML' },
  );
}

export function createAdminBot() {
  const token = getSecret('admin_bot_token');
  if (!token) {
    log.warn('admin_bot_token غير مضبوط — بوت الأدمن مش شغّال');
    return null;
  }

  const bot = new Telegraf(token);

  // جدار حماية: ما حدا غير الأدمن يمر
  bot.use((ctx, next) => {
    if (!ctx.from || !isAdmin(ctx.from.id)) {
      log.warn('blocked non-admin', { id: ctx.from?.id });
      return undefined;
    }
    return next();
  });

  bot.start(safe(async (ctx) => {
    await ctx.reply(
      [
        '🛠 <b>لوحة الأدمن</b>',
        '',
        `الرابط: ${code(panelUrl())}`,
        '',
        '/pending — طلبات السحب',
        '/events — حوالات ما انطابقت',
        '/stats — إحصاءات',
        '/user &lt;id&gt; — بطاقة مستخدم',
        '/block &lt;id&gt; — إيقاف/تفعيل',
        '/broadcast &lt;نص&gt; — رسالة لكل المستخدمين',
      ].join('\n'),
      { parse_mode: 'HTML' },
    );
  }));

  bot.command('menu', safe(async (ctx) => { await ctx.reply('استعمل /start'); }));
  bot.command('panel', safe(async (ctx) => ctx.reply(`لوحة التحكم: ${panelUrl()}`)));
  bot.command('pending', safe(sendPendingWithdrawals));
  bot.command('events', safe(sendOrphans));
  bot.command('stats', safe(sendStats));

  bot.command('user', safe(async (ctx) => {
    const id = Number(String(ctx.message.text || '').split(/\s+/)[1]);
    if (!id) throw new InputError('اكتب: /user 123456789');
    const u = users.getUser(id);
    if (!u) throw new InputError('ما في مستخدم بهالـ ID');
    const hist = ledger.history(id, 5);
    await ctx.reply(
      [
        `👤 <b>${esc(u.full_name || '—')}</b> ${u.username ? `(@${esc(u.username)})` : ''}`,
        `ID: ${code(u.id)}`,
        `الحالة: ${u.status === 'active' ? '✅ نشط' : '⛔ موقوف'}`,
        `💰 الرصيد: ${bold(formatMinor(u.balance, SHOP_CURRENCY))}`,
        u.ichancy_username ? `🎮 آيسانسي: ${code(u.ichancy_username)}` : '',
        '',
        '<b>آخر الحركات:</b>',
        ...(hist.length
          ? hist.map((h) => `${h.type} ${h.direction > 0 ? '+' : '−'}${formatMinor(h.amount)} → ${formatMinor(h.balance_after)}`)
          : ['—']),
      ].filter(Boolean).join('\n'),
      { parse_mode: 'HTML' },
    );
  }));

  bot.command('block', safe(async (ctx) => {
    const id = Number(String(ctx.message.text || '').split(/\s+/)[1]);
    if (!id) throw new InputError('اكتب: /block 123456789');
    const u = users.getUser(id);
    if (!u) throw new InputError('ما في مستخدم بهالـ ID');
    const next = u.status === 'active' ? 'blocked' : 'active';
    users.setStatus(id, next);
    audit({ actor: `admin:${ctx.from.id}`, action: 'user.status', target: id, meta: { status: next } });
    await ctx.reply(`${next === 'active' ? '✅ فُعّل' : '⛔ أُوقف'} المستخدم ${id}`);
  }));

  bot.command('add', safe(async (ctx) => {
    const [, id, amount] = String(ctx.message.text || '').split(/\s+/);
    const minor = toMinor(amount, SHOP_CURRENCY);
    const out = ledger.credit(Number(id), minor, {
      type: 'adjust', refType: 'admin', refId: String(ctx.from.id), meta: { reason: 'تعديل يدوي' },
    });
    audit({ actor: `admin:${ctx.from.id}`, action: 'balance.add', target: id, meta: { amount: minor } });
    await ctx.reply(`✅ أُضيف ${formatMinor(minor)}. الرصيد الجديد: ${formatMinor(out.balance)}`);
  }));

  bot.command('take', safe(async (ctx) => {
    const [, id, amount] = String(ctx.message.text || '').split(/\s+/);
    const minor = toMinor(amount, SHOP_CURRENCY);
    const out = ledger.debit(Number(id), minor, {
      type: 'adjust', refType: 'admin', refId: String(ctx.from.id), meta: { reason: 'تعديل يدوي' },
    });
    audit({ actor: `admin:${ctx.from.id}`, action: 'balance.take', target: id, meta: { amount: minor } });
    await ctx.reply(`✅ خُصم ${formatMinor(minor)}. الرصيد الجديد: ${formatMinor(out.balance)}`);
  }));

  bot.command('broadcast', safe(async (ctx) => {
    const text = String(ctx.message.text || '').replace(/^\/broadcast\s*/, '').trim();
    if (!text) throw new InputError('اكتب الرسالة بعد الأمر');
    const allUsers = all('SELECT id FROM users WHERE status = ?', 'active');
    let sent = 0; let failed = 0;
    for (const u of allUsers) {
      try {
        await ctx.telegram.sendMessage(u.id, `📢 ${text}`, { parse_mode: 'HTML' });
        sent += 1;
      } catch {
        failed += 1;
      }
      await new Promise((r) => setTimeout(r, 50)); // احترام حدود تيليغرام
    }
    audit({ actor: `admin:${ctx.from.id}`, action: 'broadcast', meta: { sent, failed } });
    await ctx.reply(`📢 تم الإرسال لـ ${sent} مستخدم (فشل ${failed}).`);
  }));

  /* ------------------------------- موافقات السحب ------------------------------- */

  bot.action(/^w:ok:(.+)$/, safe(async (ctx) => {
    const id = ctx.match[1];
    const w = withdrawals.approve(id, ctx.from.id);
    await ctx.editMessageReplyMarkup({}).catch(() => {});
    await ctx.reply(`✅ تم تأكيد السحب ${code(w.id)}\nالصافي: ${formatMinor(w.net_amount)} للحساب ${code(w.account)}`);
    const row = one('SELECT * FROM withdrawals WHERE id = ?', id);
    if (row) {
      const u = users.getUser(row.user_id);
      if (u) {
        await ctx.telegram.sendMessage(u.id, `✅ تم تنفيذ طلب السحب ${formatMinor(w.net_amount)}.\nمن فضلك تأكيد استلامك للمبلغ.`).catch(() => {});
      }
    }
  }));

  bot.action(/^w:no:(.+)$/, safe(async (ctx) => {
    const id = ctx.match[1];
    const w = withdrawals.reject(id, ctx.from.id, 'مرفوض من الأدمن');
    await ctx.editMessageReplyMarkup({}).catch(() => {});
    await ctx.reply(`❌ رُفض السحب ${code(w.id)} — رجع ${formatMinor(w.amount)} لرصيد المستخدم.`);
    const u = users.getUser(w.user_id);
    if (u) {
      await ctx.telegram.sendMessage(
        u.id,
        `❌ انرفض طلب السحب ${formatMinor(w.amount)}.\nرجع المبلغ كامل لرصيدك. رصيدك الآن: ${formatMinor(u.balance, SHOP_CURRENCY)}`,
      ).catch(() => {});
    }
  }));

  /* ------------------------------ مراجعة الإيداعات ----------------------------- */

  bot.action(/^d:ok:(.+)$/, safe(async (ctx) => {
    const id = ctx.match[1];
    payments.verifyManual(id, ctx.from.id);
    await ctx.editMessageReplyMarkup({}).catch(() => {});
    await ctx.reply(`✅ تم شحن الطلب ${code(id)} يدوياً.`);
  }));

  bot.action(/^d:no:(.+)$/, safe(async (ctx) => {
    const id = ctx.match[1];
    payments.rejectDeposit(id, ctx.from.id, 'مرفوض يدوياً');
    await ctx.editMessageReplyMarkup({}).catch(() => {});
    await ctx.reply(`❌ رُفض الطلب ${code(id)}.`);
  }));

  bot.action(/^ad:stats$/, safe(sendStats));
  bot.action(/^ad:pending$/, safe(sendPendingWithdrawals));
  bot.action(/^ad:events$/, safe(sendOrphans));

  // الإشعارات: بتروح على بوت الأدمن، فبوت العملاء يضل نظيف
  registerSender(async (text) => {
    const target = bot.telegram;
    for (const id of config.adminIds) {
      await target.sendMessage(id, text, { parse_mode: 'HTML' }).catch(() => {});
    }
  });

  bot.catch((err) => log.error('telegraf admin', { err: String(err) }));
  return bot;
}

export { sendStats };
