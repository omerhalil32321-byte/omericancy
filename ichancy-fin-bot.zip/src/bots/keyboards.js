import { Markup } from 'telegraf';
import * as settings from '../services/settings.js';
import { formatMinor, SHOP_CURRENCY } from '../utils/money.js';

export const NOOP = 'noop';

export function mainMenu() {
  return Markup.inlineKeyboard([
    ['🎮 إنشاء حساب آيسانسي', 'nav:ichancy'],
    ['💰 شحن الرصيد', 'nav:deposit'],
    ['🏧 سحب الرصيد', 'nav:withdraw'],
    ['🎁 إهداء صديق / كود جائزة', 'nav:gift'],
    ['🆘 الدعم الفني', 'nav:support'],
    ['📜 آخر 5 عمليات', 'nav:history'],
  ]).resize();
}

export function backRow(to = 'nav:menu') {
  return Markup.inlineKeyboard([['⬅️ رجوع للقائمة', to]]).resize();
}

export function depositMethods() {
  const list = settings.paymentMethods().filter((m) => m.label);
  if (!list.length) return Markup.inlineKeyboard([['لا توجد طرق دفع مفعّلة']]).resize();
  return Markup.inlineKeyboard([
    ...list.map((m) => [`${m.label} · ${m.currency}`, `dp:method:${m.id}`]),
    ['⬅️ رجوع', 'nav:menu'],
  ]).resize();
}

export function withdrawMethods() {
  const list = settings.paymentMethods().filter((m) => m.label);
  if (!list.length) return Markup.inlineKeyboard([['لا توجد طرق سحب مفعّلة']]).resize();
  return Markup.inlineKeyboard([
    ...list.map((m) => [`${m.label}`, `wd:method:${m.id}`]),
    ['⬅️ رجوع', 'nav:menu'],
  ]).resize();
}

export function confirmRow(yesData, noData = 'nav:menu') {
  return Markup.inlineKeyboard([
    ['✅ تأكيد', yesData],
    ['❌ إلغاء', noData],
  ]).resize();
}

export function txSubmittedRow(depId) {
  return Markup.inlineKeyboard([
    ['✅ أرسلت الحوالة — تحقّق الآن', `dp:check:${depId}`],
    ['❌ إلغاء', 'nav:menu'],
  ]).resize();
}

export function historyKeyboards() {
  return Markup.inlineKeyboard([['🔄 تحديث', 'nav:history'], ['⬅️ القائمة', 'nav:menu']]).resize();
}

export { formatMinor, SHOP_CURRENCY };
