import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { config } from '../config.js';
import * as shamcash from '../integrations/shamcash/index.js';
import * as payments from '../services/payments.js';
import * as withdrawals from '../services/withdrawals.js';
import * as users from '../services/users.js';
import * as ledger from '../services/ledger.js';
import * as settings from '../services/settings.js';
import { credentialList, setCredential, deleteCredential, getSecret } from '../services/vault.js';
import { audit, recent as recentAudit } from '../services/audit.js';
import { all, one } from '../db/index.js';
import { formatMinor, toMinor, SHOP_CURRENCY } from '../utils/money.js';
import { AppError } from '../services/errors.js';
import {
  login, logout, requireAuth, requireCsrf, csrfToken, currentAdmin, checkLogin,
} from './auth.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('web');
const views = path.join(path.dirname(fileURLToPath(import.meta.url)), 'views');

const CRON_KEYS = {
  'bonus.deposit_pct': 'bonusPct',
  'bonus.deposit_fixed': 'bonusFixed',
  'bonus.min_amount': 'bonusMin',
  'withdraw.fee_pct': 'wdFeePct',
  'withdraw.fee_fixed': 'wdFeeFixed',
  'withdraw.min': 'wdMin',
  'withdraw.max': 'wdMax',
  'rates.USD': 'rateUsd',
  'rates.USDT': 'rateUsdt',
  'shop.name': 'shopName',
  'shop.support_username': 'supportUsername',
  'deposit.auto_verify': 'autoVerify',
  'deposit.expires_hours': 'expiresHours',
  'ichancy.driver': 'ichDriver',
  'ichancy.signup_url': 'ichSignupUrl',
  'ichancy.email_domain': 'ichEmailDomain',
  'ichancy.accounts_per_user': 'ichPerUser',
};

export function createServer() {
  const app = express();
  app.set('view engine', 'ejs');
  app.set('views', views);
  app.set('trust proxy', 1);
  app.disable('x-powered-by');

  app.use(cookieParser());

  /* ------------------------------ helpers ------------------------------ */
  app.use((req, res, next) => {
    res.locals.adminId = currentAdmin(req);
    res.locals.csrf = csrfToken(req);
    res.locals.money = (v, c) => formatMinor(v, c || SHOP_CURRENCY);
    res.locals.query = req.query;
    res.locals.fmtDate = (iso) => (iso ? new Date(iso).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }) : '—');
    res.locals.flash = null;
    next();
  });

  /* --------------------- webhook شام كاش (قبل JSON) --------------------- */
  app.post(
    '/webhook/shamcash',
    express.raw({ type: '*/*', limit: '1mb' }),
    (req, res) => {
      const raw = req.body?.toString('utf8') || '';
      const out = shamcash.handle(raw, req.headers);
      res.status(out.code).json({
        ok: out.ok,
        result: out.result ?? null,
        reason: out.reason ?? null,
        error: out.error ?? null,
      });
    },
  );

  app.use(express.urlencoded({ extended: true, limit: '1mb' }));
  app.use(express.json({ limit: '1mb' }));

  app.get('/health', (_req, res) => {
    res.json({ ok: true, uptime: process.uptime(), ts: new Date().toISOString() });
  });

  /* ------------------------------- login ------------------------------- */
  app.get('/login', (req, res) => {
    if (currentAdmin(req)) return res.redirect('/');
    return res.render('login', { error: null, adminIds: config.adminIds });
  });

  app.post('/login', (req, res) => {
    try {
      const adminId = checkLogin(req);
      login(req, res, adminId);
      audit({ actor: `web:${req.ip}`, action: 'login.ok', target: adminId, ip: req.ip });
      return res.redirect('/');
    } catch (err) {
      return res.status(401).render('login', {
        error: err instanceof AppError ? err.message : 'فشل تسجيل الدخول',
        adminIds: config.adminIds,
      });
    }
  });

  app.post('/logout', (req, res) => {
    logout(req, res);
    res.redirect('/login');
  });

  /* --------------------------- كل ما بعد = محمي -------------------------- */
  app.use(requireAuth);
  app.use((req, res, next) => {
    if (req.method === 'GET') return next();
    return requireCsrf(req, res, next);
  });

  app.get('/', (req, res) => {
    const u = users.stats();
    const d = payments.depositStats();
    const w = withdrawals.withdrawStats();
    const flow = ledger.totalFlow();
    const integrity = ledger.verifyIntegrity();
    res.render('dashboard', {
      title: 'الرئيسية',
      u, d, w, flow, integrity,
      pendingWithdrawals: withdrawals.listWithdrawals({ status: 'pending', limit: 5 }).rows,
      openTickets: all(`SELECT * FROM support_tickets WHERE status='open' ORDER BY created_at DESC LIMIT 5`),
      botLinks: {
        main: one(`SELECT hint, updated_at FROM credentials WHERE name='main_bot_token'`) || null,
        admin: one(`SELECT hint, updated_at FROM credentials WHERE name='admin_bot_token'`) || null,
      },
    });
  });

  app.get('/users', (req, res) => {
    const q = String(req.query.q || '');
    const page = Math.max(1, Number(req.query.page) || 1);
    const { rows, total } = users.listUsers({ q, limit: 50, offset: (page - 1) * 50 });
    res.render('users', { title: 'المستخدمين', rows, total, q, page });
  });

  app.get('/users/:id', (req, res) => {
    const u = users.getUser(req.params.id);
    if (!u) return res.status(404).render('404', { title: 'غير موجود' });
    return res.render('user', {
      title: `مستخدم ${u.id}`,
      u,
      hist: ledger.history(u.id, 30),
      deposits: payments.listDeposits({ limit: 20 }).rows.filter((d) => d.user_id === u.id),
      withdrawals: withdrawals.listWithdrawals({ limit: 50 }).rows.filter((w) => w.user_id === u.id),
    });
  });

  app.post('/users/:id/:action', (req, res) => {
    const { id, action } = req.params;
    const u = users.getUser(id);
    if (!u) return res.status(404).send('غير موجود');

    if (action === 'block' || action === 'unblock') {
      const next = action === 'block' ? 'blocked' : 'active';
      users.setStatus(id, next);
      audit({ actor: `web:${req.ip}`, action: 'user.status', target: id, meta: { status: next }, ip: req.ip });
    } else if (action === 'add' || action === 'take') {
      const minor = toMinor(req.body.amount, SHOP_CURRENCY);
      if (minor <= 0) return res.status(400).send('مبلغ غير صالح');
      const entry = { type: 'adjust', refType: 'admin', refId: String(req.adminId), meta: { reason: req.body.reason || 'لوحة التحكم' } };
      if (action === 'add') ledger.credit(id, minor, entry);
      else ledger.debit(id, minor, entry);
      audit({ actor: `web:${req.adminId}`, action: `balance.${action}`, target: id, meta: { amount: minor }, ip: req.ip });
    }
    return res.redirect(`/users/${id}`);
  });

  app.get('/deposits', (req, res) => {
    const status = req.query.status || null;
    res.render('deposits', { title: 'الإيداعات', ...payments.listDeposits({ status, limit: 100 }), status });
  });

  app.post('/deposits/:id/:action', (req, res) => {
    const { id, action } = req.params;
    if (action === 'verify') payments.verifyManual(id, req.adminId);
    else if (action === 'reject') payments.rejectDeposit(id, req.adminId, req.body.reason || '');
    audit({ actor: `web:${req.adminId}`, action: `deposit.${action}`, target: id, ip: req.ip });
    return res.redirect('/deposits');
  });

  app.get('/withdrawals', (req, res) => {
    const status = req.query.status || null;
    res.render('withdrawals', { title: 'السحوبات', ...withdrawals.listWithdrawals({ status, limit: 100 }), status });
  });

  app.post('/withdrawals/:id/:action', (req, res) => {
    const { id, action } = req.params;
    try {
      if (action === 'approve') withdrawals.approve(id, req.adminId);
      else if (action === 'reject') withdrawals.reject(id, req.adminId, req.body.reason || 'مرفوض من اللوحة');
      audit({ actor: `web:${req.adminId}`, action: `withdraw.${action}`, target: id, ip: req.ip });
    } catch (err) {
      log.warn('withdraw action failed', { err: String(err.message) });
    }
    return res.redirect('/withdrawals');
  });

  app.get('/events', (_req, res) => {
    res.render('events', {
      title: 'أحداث الدفع',
      rows: all('SELECT * FROM payment_events ORDER BY created_at DESC LIMIT 200'),
    });
  });

  app.get('/settings', (_req, res) => {
    res.render('settings', {
      title: 'الإعدادات',
      s: settings.allSettings(),
      cronKeys: CRON_KEYS,
      methods: settings.get('payment_methods', []),
      shamSecretSet: Boolean(getSecret('sham_webhook_secret')),
    });
  });

  app.post('/settings', (req, res) => {
    const b = req.body;
    for (const [key, formKey] of Object.entries(CRON_KEYS)) {
      if (b[formKey] === undefined) continue;
      let value = b[formKey];
      if (typeof value === 'string' && ['true', 'false'].includes(value)) value = value === 'true';
      if (value === '') continue;
      settings.set(key, value);
    }

    if (Array.isArray(b.methods)) {
      const list = b.methods.map((m) => ({
        id: m.id, label: m.label, kind: m.kind || 'wallet', currency: m.currency || 'SYP',
        number: m.number || '', account: m.account || '', network: m.network || '',
        min: m.min || 0, active: m.active === 'on' || m.active === 'true',
      }));
      try {
        settings.savePaymentMethods(list);
      } catch (err) {
        log.warn('bad payment methods', { err: String(err.message) });
      }
    }

    audit({ actor: `web:${req.adminId}`, action: 'settings.update', ip: req.ip });
    res.redirect('/settings?saved=1');
  });

  app.get('/credentials', (_req, res) => {
    res.render('credentials', { title: 'التسجيل', rows: credentialList(), saved: false });
  });

  app.post('/credentials', (req, res) => {
    const { name, value } = req.body;
    if (name && value) {
      try {
        setCredential(name, value);
        audit({ actor: `web:${req.adminId}`, action: 'credential.set', target: name, ip: req.ip });
      } catch (err) {
        log.warn('credential save failed', { err: String(err.message) });
      }
    } else if (name && req.body.delete === '1') {
      deleteCredential(name);
      audit({ actor: `web:${req.adminId}`, action: 'credential.delete', target: name, ip: req.ip });
    }
    return res.redirect('/credentials?saved=1');
  });

  app.get('/audit', (_req, res) => {
    res.render('audit', { title: 'سجل العمليات', rows: recentAudit(200) });
  });

  app.use((_req, res) => res.status(404).render('404', { title: 'الصفحة مو موجودة' }));

  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    log.error('unhandled', { err: String(err.message), stack: err?.stack });
    res.status(500).send('صار خطأ بالسيرفر');
  });

  return app;
}
