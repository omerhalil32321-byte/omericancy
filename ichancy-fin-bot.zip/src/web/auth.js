import crypto from 'node:crypto';
import { config } from '../config.js';
import { getSecret } from '../services/vault.js';
import { unauthorized, forbidden } from '../services/errors.js';
import { safeEqual } from '../utils/ids.js';
import { isAdmin } from '../services/notify.js';
import { audit } from '../services/audit.js';

const COOKIE = 'fin_sid';
const MAX_AGE = 8 * 3600 * 1000;

function sessionSecret() {
  return config.sessionSecret
    || getSecret('web_password')
    || config.masterKey
    || 'dev-session-secret';
}

function sign(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const mac = crypto.createHmac('sha256', sessionSecret()).update(body).digest('base64url');
  return `${body}.${mac}`;
}

function verify(token) {
  if (!token || !token.includes('.')) return null;
  const [body, mac] = token.split('.');
  const expected = crypto.createHmac('sha256', sessionSecret()).update(body).digest('base64url');
  if (!safeEqual(mac, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!payload.exp || payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export function expectedPassword() {
  return getSecret('web_password') || config.webPassword || '';
}

export function login(req, res, adminId) {
  const token = sign({ uid: Number(adminId), exp: Date.now() + MAX_AGE });
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.isProd,
    maxAge: MAX_AGE,
  });
}

export function logout(req, res) {
  res.clearCookie(COOKIE);
}

export function currentAdmin(req) {
  return verify(req.cookies?.[COOKIE])?.uid ?? null;
}

export function requireAuth(req, res, next) {
  const uid = currentAdmin(req);
  if (!uid || !isAdmin(uid)) {
    if (req.path.startsWith('/api')) return res.status(401).json({ error: 'لازم تسجيل دخول' });
    return res.redirect('/login');
  }
  req.adminId = uid;
  return next();
}

/** حماية CSRF بسيطة: رمز مربوط بالجلسة. */
export function csrfToken(req) {
  const uid = currentAdmin(req);
  if (!uid) return '';
  return crypto.createHmac('sha256', sessionSecret()).update(`csrf:${uid}`).digest('base64url');
}

export function requireCsrf(req, res, next) {
  const expected = csrfToken(req);
  const got = req.body?._csrf || req.get('x-csrf-token') || '';
  if (!expected || !safeEqual(expected, got)) {
    audit({ actor: `web:${req.ip}`, action: 'csrf.fail', target: req.path });
    return res.status(403).send('طلب مرفوض (CSRF)');
  }
  return next();
}

export function checkLogin(req) {
  const { password, adminId } = req.body || {};
  if (!password || !adminId) throw unauthorized('اكتب كلمة السر والآيدي');
  if (!safeEqual(String(password), expectedPassword())) throw unauthorized('كلمة السر غلط');
  if (!isAdmin(Number(adminId))) throw forbidden('هذا الآيدي مو أدمن');
  return Number(adminId);
}
