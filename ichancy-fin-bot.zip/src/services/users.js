import { all, one, run } from '../db/index.js';
import { nowIso } from '../utils/time.js';
import { notFound } from './errors.js';
import { decrypt, encrypt } from './vault.js';

export function upsertUser(tg) {
  const id = Number(tg.id);
  const fullName = [tg.first_name, tg.last_name].filter(Boolean).join(' ') || null;
  const now = nowIso();
  run(
    `INSERT INTO users (id, username, full_name, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(id) DO UPDATE SET
       username  = excluded.username,
       full_name = excluded.full_name,
       updated_at = excluded.updated_at`,
    id, tg.username ?? null, fullName, now, now,
  );
  return getUser(id);
}

export function getUser(id) {
  return one('SELECT * FROM users WHERE id = ?', Number(id));
}

export function requireUser(id) {
  const user = getUser(id);
  if (!user) throw notFound('المستخدم');
  return user;
}

export function touchUser(id) {
  run('UPDATE users SET updated_at = ? WHERE id = ?', nowIso(), Number(id));
}

export function isActive(id) {
  return getUser(id)?.status === 'active';
}

export function setStatus(id, status) {
  run('UPDATE users SET status = ?, updated_at = ? WHERE id = ?', status, nowIso(), Number(id));
}

export function attachIChancy(id, { username, email, password }) {
  // كلمة السر بتتخزّن مشفّرة، وبتظهر للعميل مرة وحدة إلّا إذا طلبها تاني
  const secret = password ? encrypt(password) : null;
  run(
    `UPDATE users SET
       ichancy_username = ?,
       ichancy_email    = ?,
       ichancy_password = ?,
       updated_at       = ?
     WHERE id = ?`,
    username, email,
    secret ? JSON.stringify(secret) : null,
    nowIso(), Number(id),
  );
  return getUser(id);
}

export function readIChancyPassword(id) {
  const row = one('SELECT ichancy_password FROM users WHERE id = ?', Number(id));
  if (!row?.ichancy_password) return null;
  try {
    return decrypt(JSON.parse(row.ichancy_password));
  } catch {
    return null;
  }
}

export function listUsers({ q = '', limit = 50, offset = 0 } = {}) {
  const like = `%${q.trim()}%`;
  const rows = all(
    `SELECT id, username, full_name, balance, status, ichancy_username, created_at
     FROM users
     WHERE (? = '%%' OR CAST(id AS TEXT) LIKE ? OR IFNULL(username,'') LIKE ? OR IFNULL(full_name,'') LIKE ?)
     ORDER BY id DESC
     LIMIT ? OFFSET ?`,
    like, like, like, like, Number(limit), Number(offset),
  );
  const total = one(
    `SELECT COUNT(*) AS n FROM users
     WHERE (? = '%%' OR CAST(id AS TEXT) LIKE ? OR IFNULL(username,'') LIKE ? OR IFNULL(full_name,'') LIKE ?)`,
    like, like, like, like,
  ).n;
  return { rows, total };
}

export function stats() {
  const row = one(
    `SELECT
       COUNT(*) AS users,
       COALESCE(SUM(balance), 0) AS liabilities,
       COALESCE(SUM(CASE WHEN status = 'blocked' THEN 1 ELSE 0 END), 0) AS blocked
     FROM users`,
  );
  return { ...row, accounts: one('SELECT COUNT(*) AS n FROM users WHERE ichancy_username IS NOT NULL').n };
}
