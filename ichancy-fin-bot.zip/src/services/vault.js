// خزنة الأسرار — تشفير AES-256-GCM. التوكنات ما بتطلع أبداً للواجهة، بس تلميح (آخر 4 حروف).
import crypto from 'node:crypto';
import { loadMasterKey, readCredentialsFile } from '../config.js';
import { all, one, run } from '../db/index.js';
import { nowIso } from '../utils/time.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('vault');
const KEY = loadMasterKey();

const ENV_FALLBACK = {
  main_bot_token: 'MAIN_BOT_TOKEN',
  admin_bot_token: 'ADMIN_BOT_TOKEN',
  sham_webhook_secret: 'SHAM_WEBHOOK_SECRET',
  ichancy_api_base: 'ICHANCY_API_BASE',
  ichancy_api_key: 'ICHANCY_API_KEY',
  ichancy_email_domain: 'ICHANCY_EMAIL_DOMAIN',
  ichancy_signup_url: 'ICHANCY_SIGNUP_URL',
  web_password: 'WEB_PASSWORD',
};

export function encrypt(plain) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', KEY, iv);
  const ciphertext = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  return {
    ciphertext: ciphertext.toString('base64'),
    iv: iv.toString('base64'),
    auth_tag: cipher.getAuthTag().toString('base64'),
  };
}

export function decrypt({ ciphertext, iv, auth_tag }) {
  const decipher = crypto.createDecipheriv(
    'aes-256-gcm',
    KEY,
    Buffer.from(iv, 'base64'),
  );
  decipher.setAuthTag(Buffer.from(auth_tag, 'base64'));
  return Buffer.concat([
    decipher.update(Buffer.from(ciphertext, 'base64')),
    decipher.final(),
  ]).toString('utf8');
}

const hint = (value) => {
  const s = String(value);
  return s.length <= 4 ? '••••' : `${'•'.repeat(Math.min(8, s.length - 4))}${s.slice(-4)}`;
};

export function setCredential(name, value) {
  const clean = String(value ?? '').trim();
  if (!clean) throw new Error('القيمة فاضية');
  const { ciphertext, iv, auth_tag } = encrypt(clean);
  run(
    `INSERT INTO credentials (name, ciphertext, iv, auth_tag, hint, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)
     ON CONFLICT(name) DO UPDATE SET
       ciphertext = excluded.ciphertext,
       iv         = excluded.iv,
       auth_tag    = excluded.auth_tag,
       hint        = excluded.hint,
       updated_at  = excluded.updated_at`,
    name, ciphertext, iv, auth_tag, hint(clean), nowIso(),
  );
  return { name, hint: hint(clean) };
}

export function deleteCredential(name) {
  return run('DELETE FROM credentials WHERE name = ?', name).changes > 0;
}

/** يقرأ من القاعدة أولاً، ثم config/credentials.json، ثم متغيّر البيئة. */
export function getSecret(name) {
  const row = one('SELECT ciphertext, iv, auth_tag FROM credentials WHERE name = ?', name);
  if (row) {
    try {
      return decrypt(row);
    } catch (err) {
      log.error('failed to decrypt credential — MASTER_KEY maybe changed?', { name, err: String(err) });
      return null;
    }
  }
  const file = readCredentialsFile();
  if (file[name]) return String(file[name]);
  const envKey = ENV_FALLBACK[name];
  if (envKey && process.env[envKey]) return process.env[envKey];
  return null;
}

/** للعرض في اللوحة — ما بيكشف أي سر. */
export function credentialList() {
  const fromDb = allCredentials();
  if (fromDb.length) return fromDb;

  // ما في شي بالقاعدة؟ ورّينا موجودات الملف والـ env كمؤشرات فقط
  const file = readCredentialsFile();
  const seen = new Set();
  const out = [];

  for (const [name, value] of Object.entries(file)) {
    if (name.startsWith('_') || !String(value || '').trim()) continue;
    seen.add(name);
    out.push({ name, source: 'file', hint: hint(value), updated_at: null });
  }

  for (const [name, envKey] of Object.entries(ENV_FALLBACK)) {
    const value = process.env[envKey];
    if (!value || seen.has(name)) continue;
    seen.add(name);
    out.push({ name, source: 'env', hint: hint(value), updated_at: null });
  }

  return out;
}

function allCredentials() {
  return all('SELECT name, hint, updated_at, \'db\' AS source FROM credentials ORDER BY name');
}
