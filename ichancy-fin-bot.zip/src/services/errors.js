export class AppError extends Error {
  constructor(code, message, meta = {}) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.meta = meta;
  }
  static from(err, fallbackCode = 'internal') {
    if (err instanceof AppError) return err;
    return new AppError(fallbackCode, err?.message || 'صار خطأ غير متوقع', { cause: String(err) });
  }
}

export const badInput = (msg, meta) => new AppError('bad_input', msg, meta);
export const notFound = (what = 'العنصر') => new AppError('not_found', `${what} غير موجود`);
export const forbidden = (msg = 'ما عندك صلاحية') => new AppError('forbidden', msg);
export const conflict = (msg, meta) => new AppError('conflict', msg, meta);
export const insufficientFunds = (msg = 'رصيدك مو كافي') => new AppError('insufficient_funds', msg);
export const unauthorized = (msg = 'لازم تسجل دخول') => new AppError('unauthorized', msg);
