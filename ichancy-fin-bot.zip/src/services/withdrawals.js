// سحوبات: المال بينحجز وقت الطلب، وبيرجع كامل تلقائياً إذا رفض الأدمن.
import { all, one, run, tx } from '../db/index.js';
import { nowIso } from '../utils/time.js';
import { requestId } from '../utils/ids.js';
import { toMinor, SHOP_CURRENCY, formatMinor } from '../utils/money.js';
import * as ledger from './ledger.js';
import * as settings from './settings.js';
import { getUser } from './users.js';
import { badInput, conflict, notFound } from './errors.js';
import { audit } from './audit.js';
import { notifyAdmins } from './notify.js';

export function quote(methodId, amountInput) {
  const method = settings.paymentMethod(methodId);
  if (!method || method.active === false) throw badInput('طريقة السحب غير متاحة');

  const amount = toMinor(amountInput, SHOP_CURRENCY);
  if (amount <= 0) throw badInput('المبلغ لازم يكون أكبر من صفر');

  const pct = Number(settings.get('withdraw.fee_pct', 0)) || 0;
  const fixed = toMinor(settings.get('withdraw.fee_fixed', 0), SHOP_CURRENCY);
  const fee = Math.floor((amount * pct) / 100) + fixed;
  const net = amount - fee;
  if (net <= 0) throw badInput('العمولة أكبر من المبلغ المطلوب');

  const min = Number(settings.get('withdraw.min', 0)) || 0;
  const max = Number(settings.get('withdraw.max', 0)) || 0;
  if (min && amount < toMinor(min, SHOP_CURRENCY)) throw badInput(`أقل مبلغ سحب ${min}`);
  if (max && amount > toMinor(max, SHOP_CURRENCY)) throw badInput(`أكبر مبلغ سحب ${max}`);

  return { method, amount, fee, net };
}

const requestTx = tx(({ userId, methodId, account, amount }) => {
  const user = getUser(userId);
  if (!user) throw notFound('المستخدم');
  if (user.status !== 'active') throw badInput('حسابك موقوف حالياً');

  // التحقق الصريح: لازم يكون فيه رصيد قبل ما نعمل أي شي
  if (user.balance <= 0) {
    throw badInput('لا يوجد لديك رصيد كافي للقيام بعملية السحب');
  }

  const cleanAccount = String(account || '').trim();
  if (cleanAccount.length < 4) throw badInput('رقم الحساب/المحفظة غير صالح');

  const quote_ = quote(methodId, amount);
  const { method, fee, net } = quote_;

  const id = requestId('wdr');
  const now = nowIso();

  // الحجز: خصم فوري حتى ما يقدر يصرف نفس الفلوس مرتين
  ledger.debit(user.id, quote_.amount, {
    type: 'withdraw_hold', refType: 'withdrawal', refId: id,
    meta: { method: method.id, account: cleanAccount, fee, net },
  });

  run(
    `INSERT INTO withdrawals (id, user_id, method, account, amount, fee, net_amount, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    id, user.id, method.id, cleanAccount, quote_.amount, fee, net, now,
  );

  return one('SELECT * FROM withdrawals WHERE id = ?', id);
});

export function request(userId, { methodId, account, amount }) {
  const out = requestTx({ userId, methodId, account, amount });
  audit({ actor: `user:${userId}`, action: 'withdraw.request', target: out.id, meta: { amount: out.amount, net: out.net_amount } });
  notifyAdmins(
    `🏧 <b>طلب سحب جديد</b>\nالمستخدم: <code>${userId}</code>\nالطريقة: ${out.method}\nالحساب: <code>${out.account}</code>\nالمبلغ: ${formatMinor(out.amount)}\nالصافي بعد العمولة: ${formatMinor(out.net_amount)}`,
    { kind: 'withdraw_request', withdrawalId: out.id },
  );
  return out;
}

export function approve(id, adminId) {
  return tx(() => {
    const w = one('SELECT * FROM withdrawals WHERE id = ?', id);
    if (!w) throw notFound('طلب السحب');
    if (w.status !== 'pending') throw conflict(`الطلب بحالة ${w.status}`);

    // الرصيد انحجز وقت الطلب، فالتسوية بس تغيير حالة + توثيق
    run(`UPDATE withdrawals SET status='approved', admin_id=?, resolved_at=? WHERE id=?`, adminId, nowIso(), id);
    audit({ actor: `admin:${adminId}`, action: 'withdraw.approve', target: id, meta: { net: w.net_amount, fee: w.fee } });
    return one('SELECT * FROM withdrawals WHERE id = ?', id);
  })();
}

export function reject(id, adminId, note = '') {
  return tx(() => {
    const w = one('SELECT * FROM withdrawals WHERE id = ?', id);
    if (!w) throw notFound('طلب السحب');
    if (w.status !== 'pending') throw conflict(`الطلب بحالة ${w.status}`);

    // إعادة المبلغ كاملة تلقائياً
    ledger.credit(w.user_id, w.amount, {
      type: 'withdraw_refund', refType: 'withdrawal', refId: id, meta: { note },
    });

    run(`UPDATE withdrawals SET status='rejected', admin_id=?, note=?, resolved_at=? WHERE id=?`, adminId, note, nowIso(), id);
    audit({ actor: `admin:${adminId}`, action: 'withdraw.reject', target: id, meta: { note, refund: w.amount } });
    return one('SELECT * FROM withdrawals WHERE id = ?', id);
  })();
}

export function getWithdrawal(id) {
  return one('SELECT * FROM withdrawals WHERE id = ?', id);
}

export function listWithdrawals({ status, limit = 50, offset = 0 } = {}) {
  const rows = all(
    `SELECT w.*, u.username, u.full_name, u.balance FROM withdrawals w
     LEFT JOIN users u ON u.id = w.user_id
     WHERE (? IS NULL OR w.status = ?)
     ORDER BY w.created_at DESC LIMIT ? OFFSET ?`,
    status ?? null, status ?? null, Number(limit), Number(offset),
  );
  const total = one(
    `SELECT COUNT(*) AS n FROM withdrawals WHERE (? IS NULL OR status = ?)`,
    status ?? null, status ?? null,
  ).n;
  return { rows, total };
}

export function withdrawStats() {
  return one(
    `SELECT
       COALESCE(SUM(CASE WHEN status='pending'  THEN 1 ELSE 0 END),0) AS pending,
       COALESCE(SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END),0) AS approved,
       COALESCE(SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END),0) AS rejected,
       COALESCE(SUM(CASE WHEN status='approved' THEN fee ELSE 0 END),0) AS fees
     FROM withdrawals`,
  );
}
