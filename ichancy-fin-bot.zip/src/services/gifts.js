// إهداء الرصيد بين المستخدمين + أكواد الجائزة. كل التحويل ذرّي: ناقص أو موجود.
import { all, run, tx } from '../db/index.js';
import { nowIso } from '../utils/time.js';
import { requestId, giftCode } from '../utils/ids.js';
import { toMinor, normalizeDigits, SHOP_CURRENCY } from '../utils/money.js';
import * as ledger from './ledger.js';
import { getUser } from './users.js';
import { badInput, notFound, conflict } from './errors.js';
import { audit } from './audit.js';

const transferTx = tx(({ fromId, toId, amount, code = null }) => {
  const from = getUser(fromId);
  const to = getUser(toId);
  if (!from) throw notFound('المرسِل');
  if (!to) throw notFound('المستلم');
  if (from.status !== 'active') throw badInput('حسابك موقوف');
  if (to.status !== 'active') throw badInput('حساب المستلم موقوف');
  if (from.id === to.id) throw badInput('ما بتقدر تهدّي حالك');

  ledger.debit(from.id, amount, {
    type: 'gift_out', refType: 'gift', refId: code, meta: { to: to.id },
  });
  ledger.credit(to.id, amount, {
    type: 'gift_in', refType: 'gift', refId: code, meta: { from: from.id },
  });

  const id = requestId('gift');
  run(
    `INSERT INTO gifts (id, code, from_user_id, to_user_id, amount, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    id, code, from.id, to.id, amount, nowIso(),
  );
  return { id, code, amount, to: to.id, from: from.id };
});

/** تحويل مباشر: من ID → إلى ID */
export function sendToId(fromId, toIdInput, amountInput) {
  const toId = Number(normalizeDigits(toIdInput).replace(/[^\d]/g, ''));
  if (!Number.isFinite(toId) || toId <= 0) throw badInput('رقم المستلم غير صالح');
  const amount = toMinor(amountInput, SHOP_CURRENCY);
  if (amount <= 0) throw badInput('المبلغ لازم يكون أكبر من صفر');

  const out = transferTx({ fromId, toId, amount });
  audit({ actor: `user:${fromId}`, action: 'gift.send', target: out.id, meta: { to: toId, amount } });
  return out;
}

/** كود جائزة: المرسل بينشئ الكود، المستلم بيفوّrede. */
export function createCode(fromId, toIdInput, amountInput) {
  const toId = Number(normalizeDigits(toIdInput).replace(/[^\d]/g, ''));
  const amount = toMinor(amountInput, SHOP_CURRENCY);
  const code = giftCode();
  if (!Number.isFinite(toId) || toId <= 0) throw badInput('رقم المستلم غير صالح');

  const out = transferTx({ fromId, toId, amount, code });
  audit({ actor: `user:${fromId}`, action: 'gift.code', target: out.id, meta: { to: toId, amount, code } });
  return out;
}

export function recentGifts(userId, limit = 5) {
  return all(
    `SELECT * FROM gifts WHERE from_user_id = ? OR to_user_id = ?
     ORDER BY created_at DESC LIMIT ?`,
    Number(userId), Number(userId), Number(limit),
  );
}

export function listGifts(limit = 50) {
  return all('SELECT * FROM gifts ORDER BY created_at DESC LIMIT ?', Number(limit));
}
