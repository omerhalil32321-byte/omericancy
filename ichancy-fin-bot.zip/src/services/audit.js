import { all, one, run } from '../db/index.js';
import { nowIso } from '../utils/time.js';

export function audit({ actor, action, target = null, meta = null, ip = null }) {
  run(
    `INSERT INTO audit_log (actor, action, target, meta, ip, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
    String(actor), String(action), target ? String(target) : null,
    meta ? JSON.stringify(meta) : null, ip, nowIso(),
  );
}

export function recent(limit = 100) {
  return all('SELECT * FROM audit_log ORDER BY id DESC LIMIT ?', Number(limit));
}
