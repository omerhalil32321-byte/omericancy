// إعدادات قابلة للتعديل من لوحة الأدمن، مع قيم افتراضية آمنة.
import { all, one, run } from '../db/index.js';
import { nowIso } from '../utils/time.js';

export const DEFAULTS = {
  'shop.name': 'متجر آيسانسي',
  'shop.support_username': '',
  'shop.currency': 'SYP',

  'bonus.deposit_pct': 0,        // نسبة البونص على الإيداع %
  'bonus.deposit_fixed': 0,      // بونص ثابت لكل إيداع
  'bonus.min_amount': 0,         // أقل مبلغ إيداع يستحق بونص

  'withdraw.fee_pct': 0,         // عمولة السحب %
  'withdraw.fee_fixed': 0,
  'withdraw.min': 0,
  'withdraw.max': 0,

  'rates.USD': 13000,            // كم ل.س يساوي 1 دولار
  'rates.USDT': 13000,

  'deposit.auto_verify': true,   // شحن تلقائي بعد مطابقة شام كاش
  'deposit.expires_hours': 12,

  'sham.amount_is_minor': false, // هل المزوّد بيبعت المبلغ بالوحدة الصغرية؟
  'sham.receiver_numbers': [],   // أرقامنا المستلِمة — إذا تولّت، أي حوالة إلينا بدونها بتترفض

  'ichancy.driver': 'mock',
  'ichancy.email_domain': 'gmail.com',
  'ichancy.signup_url': '',
  'ichancy.accounts_per_user': 1,
  // محدّدات عناصر صفحة التسجيل — عدّلها من اللوحة بدل الكود
  'ichancy.selectors': {
    username: 'input[name="username"]',
    email: 'input[name="email"]',
    password: 'input[name="password"]',
    submit: 'button[type="submit"]',
    success: null,
  },

  'payment_methods': [
    { id: 'shamcash', label: 'شام كاش', kind: 'wallet', currency: 'SYP', number: '', active: true, min: 0 },
    { id: 'syriatel', label: 'سيريتل كاش', kind: 'wallet', currency: 'SYP', number: '', active: true, min: 0 },
    { id: 'usdt', label: 'USDT', kind: 'wallet', currency: 'USDT', number: '', network: 'TRC20', active: true, min: 0 },
  ],
};

function parse(raw, fallback) {
  try {
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

export function get(key, fallback) {
  const row = one('SELECT value FROM settings WHERE key = ?', key);
  const def = key in DEFAULTS ? DEFAULTS[key] : fallback;
  if (!row) return def;
  return parse(row.value, def);
}

export function set(key, value) {
  run(
    `INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
    key, JSON.stringify(value), nowIso(),
  );
  return value;
}

export function allSettings() {
  const stored = Object.fromEntries(
    all('SELECT key, value FROM settings').map((r) => [r.key, parse(r.value, null)]),
  );
  return { ...DEFAULTS, ...stored };
}

export function publicSettings() {
  const s = allSettings();
  return {
    shopName: s['shop.name'],
    supportUsername: s['shop.support_username'],
    currency: s['shop.currency'],
    bonusPct: s['bonus.deposit_pct'],
    withdrawFeePct: s['withdraw.fee_pct'],
    minWithdraw: s['withdraw.min'],
  };
}

export function paymentMethods({ onlyActive = true } = {}) {
  const list = get('payment_methods', DEFAULTS['payment_methods']);
  if (!Array.isArray(list)) return [];
  return onlyActive ? list.filter((m) => m.active !== false) : list;
}

export function paymentMethod(id) {
  return paymentMethods({ onlyActive: false }).find((m) => m.id === id) || null;
}

export function savePaymentMethods(list) {
  if (!Array.isArray(list)) throw new Error('قائمة طرق الدفع لازم تكون مصفوفة');
  const clean = list.map((m) => ({
    id: String(m.id || '').trim(),
    label: String(m.label || '').trim(),
    kind: ['wallet', 'bank'].includes(m.kind) ? m.kind : 'wallet',
    currency: String(m.currency || 'SYP').toUpperCase(),
    number: String(m.number || '').trim(),
    account: String(m.account || '').trim(),
    network: String(m.network || '').trim(),
    min: Number(m.min) || 0,
    active: m.active !== false,
  })).filter((m) => m.id && m.label);

  const ids = new Set();
  for (const m of clean) {
    if (ids.has(m.id)) throw new Error(`معرّف مكرر في طرق الدفع: ${m.id}`);
    ids.add(m.id);
  }
  return set('payment_methods', clean);
}

export function rateFor(currency) {
  return Number(get(`rates.${String(currency).toUpperCase()}`, 1)) || 1;
}
