// قلب النظام المالي. كل تغيير رصيد لازم يمر من هون — بدون استثناءات.
// المبدأ: الرصيد المخزّن = نسخة مُحدّثة من مجموع ledger. ما في حدا يعدّل users.balance يدوي.
import { all, one, run, tx } from '../db/index.js';
import { nowIso } from '../utils/time.js';
import { insufficientFunds, notFound } from './errors.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('ledger');

export const ENTRY_TYPES = new Set([
  'deposit', 'bonus', 'withdraw_hold', 'withdraw_refund',
  'withdraw_paid', 'gift_in', 'gift_out', 'adjust',
]);

const post = tx(({ userId, type, direction, amount, refType = null, refId = null, meta = null }) => {
  if (!ENTRY_TYPES.has(type)) throw new Error(`نوع قيد غير معروف: ${type}`);
  if (!Number.isSafeInteger(amount) || amount <= 0) throw new Error('المبلغ لازم يكون عدد صحيح أكبر من صفر');
  if (direction !== 1 && direction !== -1) throw new Error('الاتجاه لازم يكون 1 أو -1');

  const user = one('SELECT id, balance FROM users WHERE id = ?', Number(userId));
  if (!user) throw notFound('المستخدم');

  const next = user.balance + direction * amount;
  if (next < 0) {
    throw insufficientFunds(
      `الرصيد غير كافي. رصيدك الحالي: ${user.balance} والمطلوب: ${amount}`,
    );
  }

  run('UPDATE users SET balance = ?, updated_at = ? WHERE id = ?', next, nowIso(), user.id);
  const info = run(
    `INSERT INTO ledger (user_id, type, direction, amount, balance_after, ref_type, ref_id, meta, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    user.id, type, direction, amount, next, refType, refId,
    meta ? JSON.stringify(meta) : null, nowIso(),
  );

  return { ledgerId: Number(info.lastInsertRowid), balance: next, previous: user.balance };
});

/** كل تغيير رصيد لازم يمر من هالوظيفة. */
export function postEntry(entry) {
  const result = post(entry);
  log.info('ledger', {
    user: entry.userId, type: entry.type,
    dir: entry.direction, amount: entry.amount, balance: result.balance,
  });
  return result;
}

export function credit(userId, amount, entry) {
  return postEntry({ userId, direction: 1, amount, ...entry });
}

export function debit(userId, amount, entry) {
  return postEntry({ userId, direction: -1, amount, ...entry });
}

export function balanceOf(userId) {
  const row = one('SELECT balance FROM users WHERE id = ?', Number(userId));
  if (!row) throw notFound('المستخدم');
  return row.balance;
}

export function hasSufficient(userId, amount) {
  return balanceOf(userId) >= amount;
}

export function history(userId, limit = 5) {
  return all(
    `SELECT * FROM ledger WHERE user_id = ? ORDER BY id DESC LIMIT ?`,
    Number(userId), Number(limit),
  );
}

export function totalFlow() {
  return one(
    `SELECT
       COALESCE(SUM(CASE WHEN type = 'deposit' THEN amount ELSE 0 END), 0) AS deposits,
       COALESCE(SUM(CASE WHEN type = 'withdraw_paid' THEN amount ELSE 0 END), 0) AS withdrawals,
       COALESCE(SUM(CASE WHEN type = 'bonus' THEN amount ELSE 0 END), 0) AS bonuses
     FROM ledger`,
  );
}

/** تدقيق: مجموع ledger لازم يطابق الرصيد المخزّن لكل مستخدم. */
export function verifyIntegrity() {
  return all(
    `SELECT u.id, u.balance AS stored, c.total AS from_ledger
     FROM users u
     JOIN (
       SELECT user_id, SUM(CASE WHEN direction = 1 THEN amount ELSE -amount END) AS total
       FROM ledger GROUP BY user_id
     ) c ON c.user_id = u.id
     WHERE u.balance <> c.total`,
  );
}
