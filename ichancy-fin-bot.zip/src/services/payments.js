// إيداعات: إنشاء الطلب، ومطابقة رقم العملية + المبلغ بدقة، والشحن التلقائي.
import { all, one, run, tx } from '../db/index.js';
import { nowIso, isoAfter, isExpired, HOUR } from '../utils/time.js';
import { requestId } from '../utils/ids.js';
import { convert, toMinor, SHOP_CURRENCY, normalizeDigits } from '../utils/money.js';
import * as ledger from './ledger.js';
import * as settings from './settings.js';
import { getUser } from './users.js';
import { badInput, conflict, notFound } from './errors.js';
import { audit } from './audit.js';
import { notifyAdmins } from './notify.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('payments');

function computeBonus(creditedMinor) {
  const pct = Number(settings.get('bonus.deposit_pct', 0)) || 0;
  const fixed = Number(settings.get('bonus.deposit_fixed', 0)) || 0;
  const min = Number(settings.get('bonus.min_amount', 0)) || 0;
  if (creditedMinor < min) return 0;
  return Math.floor((creditedMinor * pct) / 100) + toMinor(fixed, SHOP_CURRENCY);
}

/** ينشئ طلب إيداع معروض. الرصيد لسا ما اتحسب. */
export function createIntent(userId, methodId, amountInput) {
  const user = getUser(userId);
  if (!user) throw notFound('المستخدم');
  if (user.status !== 'active') throw badInput('حسابك موقوف حالياً');

  const method = settings.paymentMethod(methodId);
  if (!method || method.active === false) throw badInput('طريقة الدفع غير متاحة');

  const currency = (method.currency || 'SYP').toUpperCase();
  const amount = toMinor(amountInput, currency);
  if (amount <= 0) throw badInput('المبلغ لازم يكون أكبر من صفر');
  if (method.min && amount < toMinor(method.min, currency)) {
    throw badInput(`أقل مبلغ لهالطريقة ${method.min}`);
  }

  const rate = currency === SHOP_CURRENCY ? 1 : settings.rateFor(currency);
  const credited = currency === SHOP_CURRENCY
    ? amount
    : convert(amount, currency, SHOP_CURRENCY, rate);

  const hours = Number(settings.get('deposit.expires_hours', 12)) || 12;
  const id = requestId('dep');
  const now = nowIso();

  run(
    `INSERT INTO deposits (id, user_id, method, amount, currency, credited_amount, rate, created_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    id, user.id, method.id, amount, currency, credited, rate, now, isoAfter(hours * HOUR),
  );

  audit({ actor: `user:${user.id}`, action: 'deposit.intent', target: id, meta: { method: method.id, amount, currency } });
  return one('SELECT * FROM deposits WHERE id = ?', id);
}

/** المستخدم يحط رقم العملية بعد ما يحوّل. */
export function submitTx(depositId, txInput) {
  const txId = String(normalizeDigits(txInput)).replace(/\s+/g, '').trim();
  if (txId.length < 4) throw badInput('رقم العملية غير صالح');

  const dep = one('SELECT * FROM deposits WHERE id = ?', depositId);
  if (!dep) throw notFound('طلب الإيداع');
  if (dep.status !== 'pending') throw conflict('هذا الطلب خلص، ابدأ طلب جديد');

  const taken = one('SELECT id FROM deposits WHERE tx_id = ? AND id != ? AND status = ?', txId, depositId, 'pending');
  if (taken) throw conflict('رقم العملية مستخدم من قبل');

  run('UPDATE deposits SET tx_id = ? WHERE id = ?', txId, depositId);
  return one('SELECT * FROM deposits WHERE id = ?', depositId);
}

const verifyTx = tx(({ depositId, eventKey, adminId = null }) => {
  const dep = one('SELECT * FROM deposits WHERE id = ?', depositId);
  if (!dep) throw notFound('طلب الإيداع');
  if (dep.status === 'verified') return { deposit: dep, credited: 0, bonus: 0, already: true };
  if (dep.status !== 'pending') throw conflict(`الطلب بحالة ${dep.status}`);

  const credited = dep.credited_amount ?? dep.amount;
  const bonus = computeBonus(credited);

  // الرصيد أول — لو فشلت أي خطوة، المعاملة كلها بترجع
  ledger.credit(dep.user_id, credited, {
    type: 'deposit', refType: 'deposit', refId: dep.id,
    meta: { method: dep.method, tx_id: dep.tx_id, currency: dep.currency, amount: dep.amount },
  });
  if (bonus > 0) {
    ledger.credit(dep.user_id, bonus, {
      type: 'bonus', refType: 'deposit', refId: dep.id,
      meta: { pct: settings.get('bonus.deposit_pct', 0) },
    });
  }

  run(
    `UPDATE deposits SET status = 'verified', verified_at = ?, match_event_id = ?, reviewed_by = ?
     WHERE id = ?`,
    nowIso(), eventKey, adminId, depositId,
  );

  return { deposit: one('SELECT * FROM deposits WHERE id = ?', depositId), credited, bonus, already: false };
});

/**
 * مطابقة صارمة: لازم رقم العملية والمبلغ والعملة يطابقوا **بالضبط** وطلب واحد بس.
 * لو طلع أكثر من طلب بنفس الرقم = التباس، ما من شحن تلقائي، بيروح للأدمن.
 */
export function matchEvent({ eventKey, provider, payload, txId, amount, currency }) {
  if (eventKey) {
    const dup = one('SELECT * FROM payment_events WHERE event_key = ?', eventKey);
    if (dup) {
      log.info('duplicate event ignored', { eventKey });
      return { result: 'duplicate', event: dup };
    }
  }

  const cleanTx = String(txId ?? '').trim();
  const cur = String(currency ?? SHOP_CURRENCY).toUpperCase();
  const raw = JSON.stringify(payload ?? {});

  const record = (status, extra = {}) => {
    run(
      `INSERT INTO payment_events (event_key, provider, raw, tx_id, amount, currency, status, deposit_id, reason, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      eventKey || requestId('ev'), provider, raw, cleanTx || null,
      amount ?? null, cur, status, extra.depositId ?? null, extra.reason ?? null, nowIso(),
    );
    return { result: status, depositId: extra.depositId ?? null, reason: extra.reason ?? null };
  };

  if (!cleanTx || !Number.isSafeInteger(amount) || amount <= 0) {
    return record('invalid', { reason: 'البيانات ناقصة: رقم العملية أو المبلغ' });
  }

  const candidates = all(
    `SELECT * FROM deposits WHERE tx_id = ? AND status = 'pending'`,
    cleanTx,
  ).filter((d) => d.amount === amount && d.currency === cur && !isExpired(d.expires_at));

  if (candidates.length === 0) {
    const expired = all(
      `SELECT * FROM deposits WHERE tx_id = ? AND status IN ('pending','expired')`,
      cleanTx,
    );
    const reason = expired.length
      ? 'رقم عملية موجود بمبلغ أو عملة مختلفة'
      : 'ما في طلب إيداع مطابق لرقم العملية';
    const out = record('unmatched', { reason });
    notifyAdmins(
      `⚠️ <b>حوالة ما انطابقت</b>\nرقم العملية: <code>${cleanTx}</code>\nالمبلغ: ${amount} ${cur}\nالسبب: ${reason}`,
      { kind: 'deposit_unmatched' },
    );
    return out;
  }

  if (candidates.length > 1) {
    const out = record('unmatched', { reason: `${candidates.length} طلبات بنفس رقم العملية` });
    notifyAdmins(
      `🚨 <b>تباس برقم عملية</b> <code>${cleanTx}</code>\n—there ${candidates.length} طلبات بنفس الرقم والمبلغ. مراجعة يدوية مطلوبة.`,
      { kind: 'deposit_ambiguous' },
    );
    return out;
  }

  try {
    const res = verifyTx({ depositId: candidates[0].id, eventKey });
    record('matched', { depositId: candidates[0].id });
    audit({ actor: `event:${provider}`, action: 'deposit.verified', target: candidates[0].id, meta: { eventKey, auto: true } });
    return { result: 'matched', ...res };
  } catch (err) {
    record('unmatched', { depositId: candidates[0].id, reason: String(err.message) });
    log.error('verify failed', { err: String(err) });
    throw err;
  }
}

export function verifyManual(depositId, adminId) {
  const res = verifyTx({ depositId, adminId });
  audit({ actor: `admin:${adminId}`, action: 'deposit.verify_manual', target: depositId });
  return res;
}

export function rejectDeposit(depositId, adminId, reason = '') {
  return tx(() => {
    const dep = one('SELECT * FROM deposits WHERE id = ?', depositId);
    if (!dep) throw notFound('طلب الإيداع');
    if (dep.status !== 'pending') throw conflict(`الطلب بحالة ${dep.status}`);
    run(`UPDATE deposits SET status = 'rejected', reviewed_by = ? WHERE id = ?`, adminId, depositId);
    audit({ actor: `admin:${adminId}`, action: 'deposit.reject', target: depositId, meta: { reason } });
    return dep;
  })();
}

export function getDeposit(id) {
  return one('SELECT * FROM deposits WHERE id = ?', id);
}

export function listDeposits({ status, limit = 50, offset = 0 } = {}) {
  const rows = all(
    `SELECT d.*, u.username, u.full_name FROM deposits d
     LEFT JOIN users u ON u.id = d.user_id
     WHERE (? IS NULL OR d.status = ?)
     ORDER BY d.created_at DESC LIMIT ? OFFSET ?`,
    status ?? null, status ?? null, Number(limit), Number(offset),
  );
  const total = one(
    `SELECT COUNT(*) AS n FROM deposits WHERE (? IS NULL OR status = ?)`,
    status ?? null, status ?? null,
  ).n;
  return { rows, total };
}

export function recentForUser(userId, limit = 5) {
  return all(
    `SELECT * FROM (
       SELECT 'deposit' AS kind, d.created_at, d.status, d.amount, d.currency, d.id, d.credited_amount
       FROM deposits d WHERE d.user_id = ? AND d.status != 'pending'
       UNION ALL
       SELECT 'withdrawal', w.created_at, w.status, w.amount, 'SYP', w.id, w.net_amount
       FROM withdrawals w WHERE w.user_id = ?
       UNION ALL
       SELECT 'gift_out', g.created_at, 'completed', g.amount, 'SYP', g.id, NULL
       FROM gifts g WHERE g.from_user_id = ?
     ) ORDER BY created_at DESC LIMIT ?`,
    Number(userId), Number(userId), Number(userId), Number(limit),
  );
}

/** تنظيف دوري: طلبات خلصت مدتها ولسا pending. */
export function expireStale() {
  const info = run(
    `UPDATE deposits SET status = 'expired' WHERE status = 'pending' AND expires_at <= ?`,
    nowIso(),
  );
  if (info.changes) log.info('expired stale deposits', { count: info.changes });
  return info.changes;
}

export function depositStats() {
  return one(
    `SELECT
       COALESCE(SUM(CASE WHEN status='verified' THEN 1 ELSE 0 END),0) AS verified,
       COALESCE(SUM(CASE WHEN status='pending'   THEN 1 ELSE 0 END),0) AS pending,
       COALESCE(SUM(CASE WHEN status='rejected'  THEN 1 ELSE 0 END),0) AS rejected,
       COALESCE(SUM(CASE WHEN status='expired'   THEN 1 ELSE 0 END),0) AS expired
     FROM deposits`,
  );
}
