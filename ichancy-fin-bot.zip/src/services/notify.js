// إشعارات الأدمن. بنسجّل المرسل عند الإقلاع بدل الاستيراد، عشان ما يصير استيراد دائري.
import { config } from '../config.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('notify');

let sender = null;

export function registerSender(fn) {
  sender = fn;
}

export async function notifyAdmins(text, extra = {}) {
  if (!sender) {
    log.warn('no admin sender registered — dropping notification', { kind: extra.kind });
    return false;
  }
  try {
    await sender(text, extra);
    return true;
  } catch (err) {
    log.error('failed to notify admins', { err: String(err) });
    return false;
  }
}

/** هل هذا المستخدم أدمن؟ */
export function isAdmin(userId) {
  return config.adminIds.includes(Number(userId));
}
