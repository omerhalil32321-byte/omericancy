// تكامل شام كاش: يستقبل الـ webhook، يتحقق من التوقيع، ويطابق رقم العملية + المبلغ **بدقة**.
// القاعدة الذهبية: ما من رصيد بيتشحن إلا بعد تطابق تام 100%.
import crypto from 'node:crypto';
import { config } from '../../config.js';
import { getSecret } from '../../services/vault.js';
import * as settingsService from '../../services/settings.js';
import * as payments from '../../services/payments.js';
import { safeEqual } from '../../utils/ids.js';
import { normalizeDigits, toMinor, InputError, SHOP_CURRENCY } from '../../utils/money.js';
import { createLogger } from '../../utils/logger.js';

const log = createLogger('shamcash');

export function secret() {
  return getSecret('sham_webhook_secret') || config.sham.secret || '';
}

function hmac(rawBody, key) {
  return crypto.createHmac('sha256', key).update(rawBody).digest('hex');
}

function header(headers, ...names) {
  for (const n of names) {
    const v = headers[n] ?? headers[n.toLowerCase()];
    if (v) return String(v);
  }
  return '';
}

/**
 * يتحقق من مصدر الطلب.
 * يعتمد نوعين: HMAC-SHA256 عبر x-sham-signature، أو Bearer / x-sham-token للمقارنة المباشرة.
 * بدون سرّ ما من شحن أبداً في وضع الإنتاج.
 */
export function verifySignature(rawBody, headers = {}) {
  const key = secret();
  if (!key) {
    if (config.isProd) {
      return { ok: false, reason: 'SHAM_WEBHOOK_SECRET غير مضبوط — الرفض افتراضي' };
    }
    log.warn('SHAM_WEBHOOK_SECRET غير مضبوط — قبول الطلبات بدون تحقق (وضع التطوير فقط)');
    return { ok: true, mode: 'insecure-dev' };
  }

  const sig = header(headers, 'x-sham-signature', 'x-shamcash-signature', 'x-signature');
  if (sig) {
    const provided = sig.replace(/^sha256=/i, '').trim().toLowerCase();
    const expected = hmac(rawBody, key);
    if (safeEqual(provided, expected)) return { ok: true, mode: 'hmac' };
    return { ok: false, reason: 'التوقيع ما طابق' };
  }

  const token = header(headers, 'x-sham-token') || header(headers, 'authorization').replace(/^Bearer\s+/i, '');
  if (token && safeEqual(token.trim(), key)) return { ok: true, mode: 'bearer' };

  return { ok: false, reason: 'ما في توقيع صالح بالطلب' };
}

const pick = (obj, names) => {
  for (const n of names) {
    const v = obj[n];
    if (v !== undefined && v !== null && v !== '') return v;
  }
  return undefined;
};

const TX_KEYS = ['tx_id', 'txid', 'transactionId', 'transaction_id', 'txnId', 'operationId', 'opId', 'reference', 'ref', 'id', 'رقم العملية', 'رقم_العملية'];
const AMOUNT_KEYS = ['amount', 'value', 'total', 'received_amount', 'receivedAmount', 'amount_received', 'amountReceived', 'transferAmount', 'المبلغ'];
const CURRENCY_KEYS = ['currency', 'currencyCode', 'curr', 'coin', 'العملة'];
const SENDER_KEYS = ['sender', 'from', 'senderNumber', 'sender_number', 'fromNumber', 'from_number', 'sender_phone', 'المرسل'];
const RECEIVER_KEYS = ['receiver', 'to', 'receiverNumber', 'receiver_number', 'toNumber', 'to_number', 'recipient', 'beneficiary', 'المستلم'];
const EVENT_KEYS = ['event_id', 'eventId', 'notification_id', 'idempotency_key', 'webhook_id'];
const TIME_KEYS = ['timestamp', 'time', 'created_at', 'createdAt', 'date', 'الوقت'];

/** يحوّل حمولة المزوّد لشكل موحّد — أسماء الحقول تختلف بين الواجهات فبنقبل الكل. */
export function normalize(payload) {
  if (!payload || typeof payload !== 'object') throw new InputError('حمولة غير صالحة');
  const body = payload.data && typeof payload.data === 'object' ? { ...payload, ...payload.data } : payload;

  const currency = String(pick(body, CURRENCY_KEYS) ?? 'SYP').toUpperCase().trim();
  const rawAmount = pick(body, AMOUNT_KEYS);
  if (rawAmount === undefined) throw new InputError('ما في مبلغ بالحمولة');

  // بعض الـ APIs تبعت المبلغ بالوحدة الصغرى — نحترم الإعداد
  const isMinor = settingsService.get('sham.amount_is_minor', false) === true;
  const amount = isMinor
    ? Math.trunc(Number(normalizeDigits(rawAmount)))
    : toMinor(rawAmount, currency);

  const eventKey = String(pick(body, EVENT_KEYS) ?? '') || '';

  return {
    txId: String(normalizeDigits(pick(body, TX_KEYS) ?? '')).replace(/\s+/g, ''),
    amount,
    currency,
    sender: String(normalizeDigits(pick(body, SENDER_KEYS) ?? '')).replace(/[^\d+]/g, ''),
    receiver: String(normalizeDigits(pick(body, RECEIVER_KEYS) ?? '')).replace(/[^\d+]/g, ''),
    timestamp: pick(body, TIME_KEYS) ?? null,
    eventKey,
  };
}

function receiverAllowed(receiver) {
  const allowed = settingsService.get('sham.receiver_numbers', config.sham.receiverNumbers) ?? [];
  if (!Array.isArray(allowed) || allowed.length === 0) return true; // ما ضُبطت = ما من تحقق
  if (!receiver) return false;
  return allowed.some((n) => String(n).replace(/\D/g, '') === receiver.replace(/\D/g, ''));
}

/**
 * المعالج الرئيسي. بيرجع { code, ... } — code هو HTTP status.
 * 200 = استلمنا و swayingI la vérification. 401 = توقيع غلط. 400 = حمولة مكسورة.
 */
export function handle(rawBody, headers = {}) {
  const sig = verifySignature(rawBody, headers);
  if (!sig.ok) {
    log.warn('webhook rejected', { reason: sig.reason });
    return { code: 401, ok: false, error: sig.reason };
  }

  let payload;
  try {
    payload = typeof rawBody === 'string' ? JSON.parse(rawBody) : rawBody;
  } catch {
    return { code: 400, ok: false, error: 'JSON غير صالح' };
  }

  let evt;
  try {
    evt = normalize(payload);
  } catch (err) {
    log.warn('normalize failed', { err: String(err.message) });
    return { code: 400, ok: false, error: err.message };
  }

  if (!receiverAllowed(evt.receiver)) {
    log.warn('receiver not allowed', { receiver: evt.receiver });
    return { code: 200, ok: true, result: 'rejected', reason: 'المستلم مو ضمن أرقامنا' };
  }

  // لو المزوّد ما بعت معرّف حدث، نشتق واحد من هاش الحمولة — نفس الحمولة = نفس المفتاح
  const eventKey = evt.eventKey
    || `sha:${crypto.createHash('sha256').update(rawBody).digest('hex')}`;

  const autoVerify = settingsService.get('deposit.auto_verify', true) !== false;

  try {
    const out = payments.matchEvent({
      eventKey,
      provider: 'shamcash',
      payload,
      txId: evt.txId,
      amount: evt.amount,
      currency: evt.currency,
    });

    // لو الشحن التلقائي مقفول، ما نعتمد على شي — كل شي بيروح مراجعة يدوية
    if (out.result === 'matched' && !autoVerify) {
      log.warn('auto-verify disabled — matched event held for manual review', { eventKey });
    }

    return { code: 200, ok: true, ...out, signatureMode: sig.mode };
  } catch (err) {
    log.error('matchEvent failed', { err: String(err.message) });
    return { code: 500, ok: false, error: 'فشل معالجة الحدث — رح ينعاد المحاولة' };
  }
}

export { SHOP_CURRENCY };
