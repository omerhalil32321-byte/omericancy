// مشغّل إنشاء حسابات آيسانسي.
// ثلاث سواق، ونفس الواجهة لكلUnit منهم، فبتبدّل من اللوحة بدون ما تلمس الكود.

import { usernameCandidate, strongPassword, disposableEmail, randomToken } from '../../utils/ids.js';
import * as settings from '../../services/settings.js';
import { one } from '../../db/index.js';
import { createLogger } from '../../utils/logger.js';
import { conflict, AppError } from '../../services/errors.js';

const log = createLogger('ichancy');

function buildLocal() {
  let candidate = usernameCandidate();
  for (let i = 0; i < 8; i += 1) {
    const taken = one('SELECT id FROM users WHERE ichancy_username = ?', candidate);
    if (!taken) break;
    candidate = usernameCandidate();
  }
  const domain = settings.get('ichancy.email_domain', 'gmail.com');
  return {
    username: candidate,
    email: disposableEmail(candidate, domain),
    password: strongPassword(16),
  };
}

async function loadDriver() {
  const name = settings.get('ichancy.driver', 'mock');
  switch (name) {
    case 'mock': {
      const m = await import('./mock.js');
      return m.default;
    }
    case 'playwright': {
      const p = await import('./playwright.js');
      return p.default;
    }
    case 'api': {
      const a = await import('./api.js');
      return a.default;
    }
    default:
      throw new AppError('bad_config', `مشغّل آيسانسي غير معروف: ${name}. استخدم mock أو playwright أو api`);
  }
}

/**
 * ينشئ حساب ويعيد { username, email, password, driver }.
 * ملاحظة: هالشي بينشئ حساب حقيقي عند منفّذ التشغيل. في وضع mock ما في أي طلب خارجي.
 */
export async function createAccount({ desiredName, telegramId } = {}) {
  const driverName = settings.get('ichancy.driver', 'mock');
  const local = buildLocal();

  const driver = await loadDriver();
  log.info('creating account', { driver: driverName, username: local.username, tg: telegramId });

  try {
    const result = await driver.create({
      ...local,
      desiredName,
      signupUrl: settings.get('ichancy.signup_url', ''),
      selectors: settings.get('ichancy.selectors', {}),
      headless: process.env.ICHANCY_HEADLESS !== 'false',
    });
    return { ...result, driver: driverName };
  } catch (err) {
    log.error('driver failed', { driver: driverName, err: String(err.message) });
    // ما بيرجع اليوزرنيم المولّد للخزنة — المستخدم ما يحمله إشي
    throw new AppError('ichancy_failed', `تعذّر إنشاء الحساب: ${err.message}`);
  }
}

export function driversAvailable() {
  return ['mock', 'playwright', 'api'];
}

export { randomToken, conflict };
