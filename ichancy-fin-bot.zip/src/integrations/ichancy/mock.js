// سائق التطوير: بيانات صحيحة الشكل بدون أي طلب خارجي.
// هاد اللي بيشتغل عندك أول ما تشغّل — البوت كامل وجاهز للاستخدام فوراً.
import { MINUTE } from '../../utils/time.js';

export default {
  name: 'mock',

  async create({ username, email, password }) {
    await new Promise((r) => setTimeout(r, 400)); // نحاكي زمن الشبكة
    return {
      ok: true,
      username,
      email,
      password,
      createdAt: new Date().toISOString(),
      note: 'حساب تجريبي (وضع mock) — ما انتحسّ على آيسانسي',
    };
  },
};

export { MINUTE };
