// سائق المتصفح: يفتح صفحة التسجيل بـ Playwright ويملاها.
//
// ⚠️ المحدّدات الافتراضية عامة. افتح موقع آيسانسي، افحص عناصر النموذج،
// وحطها في إعدادات اللوحة (إعدادات ← آيسانسي ← محدّدات التسجيل). بدون هالشي
// السائق بيرمي خطأ واضح بدل ما يطنّش بصمت.
import { createLogger } from '../../utils/logger.js';

const log = createLogger('ichancy:playwright');

let browserPromise = null;

async function getBrowser(headless) {
  if (!browserPromise) {
    const { chromium } = await import('playwright');
    browserPromise = chromium.launch({
      headless,
      args: ['--no-sandbox', '--disable-dev-shm-usage'],
    });
  }
  return browserPromise;
}

export async function closeBrowser() {
  if (browserPromise) {
    const b = await browserPromise;
    await b.close().catch(() => {});
    browserPromise = null;
  }
}

async function fill(page, selector, value, label) {
  const el = page.locator(selector).first();
  try {
    await el.waitFor({ state: 'visible', timeout: 20_000 });
    await el.fill(value);
  } catch {
    throw new Error(
      `ما قدرت أملأ حقل "${label}". تأكد من المحدّد «${selector}» في إعدادات آيسانسي.`,
    );
  }
}

export default {
  name: 'playwright',

  async create({ username, email, password, signupUrl, selectors = {}, headless = true }) {
    if (!signupUrl) {
      throw new Error('ICHANCY_SIGNUP_URL غير مضبوط — حط رابط صفحة التسجيل من اللوحة');
    }

    const browser = await getBrowser(headless);
    const context = await browser.newContext({
      userAgent:
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
      locale: 'en-US',
    });
    const page = await context.newPage();

    try {
      await page.goto(signupUrl, { waitUntil: 'domcontentloaded', timeout: 45_000 });
      await fill(page, selectors.username, username, 'اسم المستخدم');
      await fill(page, selectors.email, email, 'البريد');
      await fill(page, selectors.password, password, 'كلمة السر');

      await page.locator(selectors.submit).first().click({ timeout: 20_000 });

      // بعد الإرسال: ننتظر إما مؤشر نجاح أو تغيّر بالـ URL
      if (selectors.success) {
        await page
          .locator(selectors.success)
          .first()
          .waitFor({ state: 'visible', timeout: 25_000 });
      } else {
        await page.waitForLoadState('networkidle', { timeout: 25_000 }).catch(() => {});
      }

      // كلمة السر قد تكون الحقول تغيّرت بعد التسجيل
      await fill(page, selectors.password, password, 'كلمة السر (تأكيد)').catch(() => {});

      const stillThere = await page.locator(selectors.username).first().isVisible().catch(() => false);
      if (stillThere) {
        throw new Error('الصفحة لسا بعرض نموذج التسجيل — غالبًا ما تم القبول أو في كابتشا');
      }

      log.info('account created', { username, email });
      return { ok: true, username, email, password };
    } catch (err) {
      const shot = `ichancy-error-${Date.now()}.png`;
      await page.screenshot({ path: shot, fullPage: true }).catch(() => {});
      log.error('playwright failed', { err: String(err.message), screenshot: shot });
      throw new Error(`${err.message} (صورة الخطأ: ${shot})`);
    } finally {
      await context.close().catch(() => {});
    }
  },
};
