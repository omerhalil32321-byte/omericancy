// سائق الـ API الرسمي: لو وقّع آيسانسي معك شراكة وسمعلك endpoint تسجيل، حط رابطه هون.
// بدون endpoint مضبوط، السائق بيرمي خطأ واضح وما بيحاول يتعلّم.
import { getSecret } from '../../services/vault.js';

const TIMEOUT_MS = 30_000;

export default {
  name: 'api',

  async create({ username, email, password }) {
    const base = getSecret('ichancy_api_base');
    const apiKey = getSecret('ichancy_api_key');
    if (!base || !apiKey) {
      throw new Error(
        'ICHANCY_API_BASE / ICHANCY_API_KEY غير مضبوطين. ' +
        'حطهم من اللوحة (التسجيل ← بيانات الاتصال) أو استخدم مشغّل playwright.',
      );
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

    try {
      const res = await fetch(`${String(base).replace(/\/+$/, '')}/register`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({ username, email, password }),
        signal: controller.signal,
      });

      const text = await res.text();
      if (!res.ok) throw new Error(`API رجّع ${res.status}: ${text.slice(0, 200)}`);

      const data = JSON.parse(text);
      return {
        ok: true,
        username: data.username || username,
        email: data.email || email,
        password: data.password || password,
        externalId: data.id ?? null,
      };
    } finally {
      clearTimeout(timer);
    }
  },
};
