import Database from 'better-sqlite3';
import fs from 'node:fs';
import { DB_PATH, ensureDirs } from '../config.js';
import { createLogger } from '../utils/logger.js';

ensureDirs();
const log = createLogger('db');

export const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');   // أسرع مع القراءة والكتابة المتزامنة
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');
db.pragma('synchronous = NORMAL'); // توازن بين الأمان والسرعة على WAL

const schema = fs.readFileSync(new URL('./schema.sql', import.meta.url), 'utf8');
db.exec(schema);
log.info('database ready', { path: DB_PATH });

// كاش للاستعلامات — better-sqlite3 يحضّر الجملة مرة وحدة
const cache = new Map();
function stmt(sql) {
  let s = cache.get(sql);
  if (!s) {
    s = db.prepare(sql);
    cache.set(sql, s);
  }
  return s;
}

export const one = (sql, ...params) => stmt(sql).get(...params);
export const all = (sql, ...params) => stmt(sql).all(...params);
export const run = (sql, ...params) => stmt(sql).run(...params);
export const pluck = (sql, ...params) => {
  const row = one(sql, ...params);
  if (!row) return undefined;
  return Object.values(row)[0];
};

/**
 * معاملة ذرّية: إما ينفّذ كل شي أو ما ينفّذ شي.
 * better-sqlite3 لفّها بـ SAVEPOINT تلقائياً إذا كانت متداخلة.
 */
export function tx(fn) {
  return db.transaction(fn);
}
