PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id                 INTEGER PRIMARY KEY,          -- telegram user id
  username           TEXT,
  full_name          TEXT,
  balance            INTEGER NOT NULL DEFAULT 0,   -- بالوحدة الصغرى لعملة المتجر
  status             TEXT NOT NULL DEFAULT 'active', -- active | blocked
  ichancy_username   TEXT,
  ichancy_email      TEXT,
  ichancy_password   TEXT,                         -- مشفّر AES-256-GCM
  created_at         TEXT NOT NULL,
  updated_at         TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_users_ichancy
  ON users(ichancy_username) WHERE ichancy_username IS NOT NULL;

-- سجل قائم مزدوج: كل تغيير رصيد إلو سطر. الرصيد المخزّن هو نسخة مُخزّنة من المجموع.
CREATE TABLE IF NOT EXISTS ledger (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id        INTEGER NOT NULL,
  type           TEXT NOT NULL,   -- deposit | bonus | withdraw_hold | withdraw_refund | withdraw_paid | gift_in | gift_out | adjust
  direction      INTEGER NOT NULL CHECK (direction IN (1, -1)),
  amount         INTEGER NOT NULL CHECK (amount > 0),
  balance_after  INTEGER NOT NULL,
  ref_type       TEXT,
  ref_id         TEXT,
  meta           TEXT,
  created_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_ledger_user ON ledger(user_id, id DESC);

CREATE TABLE IF NOT EXISTS deposits (
  id               TEXT PRIMARY KEY,
  user_id          INTEGER NOT NULL,
  method           TEXT NOT NULL,
  amount           INTEGER NOT NULL,   -- بعملة الإيداع الأصلية
  currency         TEXT NOT NULL,
  credited_amount  INTEGER,            -- المحوّل لعملة المتجر
  rate             REAL,
  bonus_pct        REAL NOT NULL DEFAULT 0,
  bonus_amount     INTEGER NOT NULL DEFAULT 0,
  tx_id            TEXT,
  status           TEXT NOT NULL DEFAULT 'pending', -- pending | verified | rejected | expired
  match_event_id   TEXT,
  reviewed_by      INTEGER,
  created_at       TEXT NOT NULL,
  expires_at       TEXT NOT NULL,
  verified_at      TEXT
);
CREATE INDEX IF NOT EXISTS ix_deposits_user ON deposits(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_deposits_tx   ON deposits(tx_id);
CREATE INDEX IF NOT EXISTS ix_deposits_st   ON deposits(status, created_at DESC);

-- كل webhook وارد بينخزّن مرة وحدة (event_key = PRIMARY KEY) = حماية من التكرار
CREATE TABLE IF NOT EXISTS payment_events (
  event_key   TEXT PRIMARY KEY,
  provider    TEXT NOT NULL,
  raw         TEXT NOT NULL,
  tx_id       TEXT,
  amount      INTEGER,
  currency    TEXT,
  status      TEXT NOT NULL,   -- matched | unmatched | rejected | invalid | rejected_signature
  deposit_id  TEXT,
  reason      TEXT,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_events_st ON payment_events(status, created_at DESC);

CREATE TABLE IF NOT EXISTS withdrawals (
  id          TEXT PRIMARY KEY,
  user_id     INTEGER NOT NULL,
  method      TEXT NOT NULL,
  account     TEXT NOT NULL,
  amount      INTEGER NOT NULL,
  fee         INTEGER NOT NULL DEFAULT 0,
  net_amount  INTEGER NOT NULL,
  status      TEXT NOT NULL DEFAULT 'pending', -- pending | approved | rejected
  admin_id    INTEGER,
  note        TEXT,
  created_at  TEXT NOT NULL,
  resolved_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_withdrawals_user ON withdrawals(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_withdrawals_st   ON withdrawals(status, created_at DESC);

CREATE TABLE IF NOT EXISTS gifts (
  id            TEXT PRIMARY KEY,
  code          TEXT UNIQUE,
  from_user_id  INTEGER NOT NULL,
  to_user_id    INTEGER NOT NULL,
  amount        INTEGER NOT NULL,
  created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_gifts_to ON gifts(to_user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS user_state (
  user_id    INTEGER PRIMARY KEY,
  state      TEXT,
  data       TEXT,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- التوكنات والمفاتيح السرّية — مشفّرة، ما بتنعرض أبداً بالواجهة
CREATE TABLE IF NOT EXISTS credentials (
  name       TEXT PRIMARY KEY,
  ciphertext TEXT NOT NULL,
  iv         TEXT NOT NULL,
  auth_tag   TEXT NOT NULL,
  hint       TEXT,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS support_tickets (
  id          TEXT PRIMARY KEY,
  user_id     INTEGER NOT NULL,
  message     TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'open', -- open | closed
  admin_reply TEXT,
  created_at  TEXT NOT NULL,
  closed_at   TEXT
);
CREATE INDEX IF NOT EXISTS ix_support_st ON support_tickets(status, created_at DESC);

CREATE TABLE IF NOT EXISTS audit_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  actor      TEXT NOT NULL,
  action     TEXT NOT NULL,
  target     TEXT,
  meta       TEXT,
  ip         TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_audit_at ON audit_log(id DESC);
