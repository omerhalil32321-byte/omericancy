import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

export const ROOT = path.resolve(here, '..');
export const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
export const CONFIG_DIR = path.join(ROOT, 'config');
export const LOG_DIR = path.join(ROOT, 'logs');
export const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'bot.db');
export const CREDENTIALS_FILE = path.join(CONFIG_DIR, 'credentials.json');

export const isProd = process.env.NODE_ENV === 'production';

export function ensureDirs() {
  for (const dir of [DATA_DIR, CONFIG_DIR, LOG_DIR]) {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  }
}

function listEnvIds(value = '') {
  return value
    .split(/[,\s]+/)
    .map((v) => v.trim())
    .filter(Boolean)
    .map(Number)
    .filter((n) => Number.isFinite(n) && n > 0);
}

export const config = {
  port: Number(process.env.PORT || 3000),
  host: process.env.HOST || '0.0.0.0',
  publicUrl: (process.env.PUBLIC_URL || '').replace(/\/+$/, ''),
  logLevel: process.env.LOG_LEVEL || 'info',
  isProd,
  adminIds: listEnvIds(process.env.ADMIN_IDS || ''),
  masterKey: process.env.MASTER_KEY || '',
  webPassword: process.env.WEB_PASSWORD || '',
  sessionSecret: process.env.SESSION_SECRET || '',

  // تبع شام كاش — للتوقيع والتحقق من الـ webhook
  sham: {
    secret: process.env.SHAM_WEBHOOK_SECRET || '',
    receiverNumbers: listEnvIds(process.env.SHAM_RECEIVER_NUMBERS || ''),
    autoVerify: (process.env.SHAM_AUTO_VERIFY || 'true') !== 'false',
    depositExpiresHours: Number(process.env.SHAM_DEPOSIT_EXPIRES_HOURS || 12),
  },

  ichancy: {
    // mock = بيانات وهمية للتطوير بدون لمس الموقع الحقيقي
    driver: process.env.ICHANCY_DRIVER || 'mock',
    baseUrl: process.env.ICHANCY_BASE_URL || '',
    signupUrl: process.env.ICHANCY_SIGNUP_URL || '',
    emailDomain: process.env.ICHANCY_EMAIL_DOMAIN || 'gmail.com',
    headless: process.env.ICHANCY_HEADLESS !== 'false',
  },
};

if (isProd && !config.adminIds.length) {
  throw new Error('ADMIN_IDS مطلوب في وضع الإنتاج — ما في حدا رح يقدر يدخل اللوحة.');
}

if (isProd && !config.masterKey) {
  throw new Error('MASTER_KEY مطلوب في وضع الإنتاج. شغّل: npm run setup');
}

/** مفتاح التشفير: من .env، وإذا مو موجود في التطوير بنولّد واحد مؤقت ونحذّر. */
export function loadMasterKey() {
  if (config.masterKey) {
    const key = Buffer.from(config.masterKey, 'base64');
    if (key.length !== 32) {
      throw new Error('MASTER_KEY لازم يكون 32 بايت بصيغة base64 (شغّل npm run setup لتوليده).');
    }
    return key;
  }
  // تطوير فقط
  const fallback = crypto.createHash('sha256').update('dev-only-key').digest();
  return fallback;
}

export function readCredentialsFile() {
  if (!fs.existsSync(CREDENTIALS_FILE)) return {};
  try {
    return JSON.parse(fs.readFileSync(CREDENTIALS_FILE, 'utf8'));
  } catch {
    return {};
  }
}
