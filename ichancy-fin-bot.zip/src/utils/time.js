export const nowIso = () => new Date().toISOString();

export function isoAfter(ms) {
  return new Date(Date.now() + ms).toISOString();
}

export function isExpired(iso) {
  if (!iso) return false;
  return new Date(iso).getTime() <= Date.now();
}

export const MINUTE = 60_000;
export const HOUR = 3_600_000;
export const DAY = 86_400_000;

export function toTgDate(iso) {
  return Math.floor(new Date(iso).getTime() / 1000);
}

export function fromTgDate(seconds) {
  return new Date(seconds * 1000).toISOString();
}
