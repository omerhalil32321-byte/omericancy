// مراقب بسيط بدون مكتبات خارجية — يطبع على console وبيحفظ بملف.
import fs from 'node:fs';
import path from 'node:path';
import { ROOT } from '../config.js';

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const COLORS = { debug: '\x1b[90m', info: '\x1b[36m', warn: '\x1b[33m', error: '\x1b[31m' };
const RESET = '\x1b[0m';

const minLevel = LEVELS[process.env.LOG_LEVEL] ?? LEVELS.info;
let stream = null;

try {
  const dir = path.join(ROOT, 'logs');
  if (fs.existsSync(dir)) stream = fs.createWriteStream(path.join(dir, 'app.log'), { flags: 'a' });
} catch { /* logging to disk is optional */ }

function emit(level, scope, msg, extra) {
  if (LEVELS[level] < minLevel) return;
  const ts = new Date().toISOString();
  const tail = extra === undefined ? '' : ` ${format(extra)}`;
  const line = `${ts} ${level.toUpperCase().padEnd(5)} [${scope}] ${msg}${tail}`;

  process.stdout.write(`${COLORS[level]}${line}${RESET}\n`);
  stream?.write(`${line}\n`);

  if (level === 'error' && extra instanceof Error) {
    process.stdout.write(`${extra.stack}\n`);
    stream?.write(`${extra.stack}\n`);
  }
}

function format(extra) {
  if (extra instanceof Error) return `${extra.message}`;
  if (typeof extra === 'string') return extra;
  try {
    return JSON.stringify(extra, (_k, v) => (typeof v === 'bigint' ? v.toString() : v));
  } catch {
    return String(extra);
  }
}

export function createLogger(scope) {
  return {
    debug: (msg, extra) => emit('debug', scope, msg, extra),
    info: (msg, extra) => emit('info', scope, msg, extra),
    warn: (msg, extra) => emit('warn', scope, msg, extra),
    error: (msg, extra) => emit('error', scope, msg, extra),
  };
}
