import crypto from 'node:crypto';

// حروف بدون ا/o/0/1/L عشان ما حداش يغلط بالقراءة
const READABLE = 'abcdefghijkmnopqrstuvwxyz23456789';
const PASSWORD_SET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';

function pick(set, len) {
  const out = [];
  for (let i = 0; i < len; i += 1) out.push(set[crypto.randomInt(set.length)]);
  return out;
}

export function randomSuffix(len = 4) {
  return pick(READABLE, len).join('');
}

/** بادأ بحرف عشان اليوزرنيم ما يبدأ برقم. */
export function usernameCandidate(base) {
  const clean = String(base || '')
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, '')
    .replace(/^_+|_+$/g, '')
    .slice(0, 14) || 'player';
  const head = /^[a-z]/.test(clean) ? clean : `u${clean}`;
  return `${head}_${randomSuffix(4)}`;
}

export function strongPassword(len = 16) {
  const chars = pick(PASSWORD_SET, len);
  // نضمن وجود رقم ورقم كبير على الأقل
  chars[0] = PASSWORD_SET[crypto.randomInt(28)];
  chars[1] = 'abcdefghijkmnopqrstuvwxyz23456789'[
    crypto.randomInt('abcdefghijkmnopqrstuvwxyz23456789'.length)
  ];
  chars[2] = 'ABCDEFGHJKLMNPQRSTUVWXYZ'[
    crypto.randomInt('ABCDEFGHJKLMNPQRSTUVWXYZ'.length)
  ];
  return chars.join('');
}

export function disposableEmail(username, domain = 'gmail.com') {
  const id = crypto.randomBytes(6).toString('hex');
  return `ch.${username.toLowerCase()}.${id}@${domain}`;
}

export function giftCode() {
  return `GIFT-${randomSuffix(4)}-${randomSuffix(4)}`;
}

export function requestId(prefix = 'req') {
  return `${prefix}_${crypto.randomBytes(6).toString('hex')}`;
}

export function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('base64url');
}

/** مقارنة ثابتة الزمن — لمنع timing attacks على التوكنات. */
export function safeEqual(a = '', b = '') {
  const bufA = Buffer.from(String(a));
  const bufB = Buffer.from(String(b));
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}
