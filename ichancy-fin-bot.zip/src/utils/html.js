const MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

/** أي نص من المستخدم لازم يمر من هون قبل ما ينحط بـ parse_mode HTML. */
export const esc = (input) => String(input ?? '').replace(/[&<>"']/g, (c) => MAP[c]);

export const code = (input) => `<code>${esc(input)}</code>`;

export const bold = (input) => `<b>${esc(input)}</b>`;
