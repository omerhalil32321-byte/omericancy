// كل المبالغ بتتخزّن كأعداد صحيحة (أصغر وحدة نقدية) — ما في floats أبداً.
// الأعداد العشرية بالمال مصدر أخطاء تراكمية. هالشي مينعناه.

export const CURRENCIES = {
  SYP: { code: 'SYP', scale: 0, symbol: 'ل.س' },
  USD: { code: 'USD', scale: 2, symbol: '$' },
  USDT: { code: 'USDT', scale: 2, symbol: 'USDT' },
};

export const SHOP_CURRENCY = 'SYP';

export function currencyOf(code) {
  return CURRENCIES[String(code || '').toUpperCase()] ?? null;
}

export function scaleOf(code) {
  return currencyOf(code)?.scale ?? 0;
}

/** يحوّل الأرقام العربية والفارسية إلى لاتينية. المستخدم بيكتّب ٥٠٠٠٠ sometimes. */
export function normalizeDigits(input) {
  return String(input ?? '')
    .replace(/[\u0660-\u0669]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[\u06f0-\u06f9]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[\u200e\u200f\u202a-\u202e]/g, '')
    .replace(/[\u00a0\u2009\u202f]/g, ' ');
}

/**
 * يحوّل مدخل المستخدم لنص إلى رقم صحيح بالوحدة الصغرى.
 * يقبل: "50,000" / "50 000" / "50000 ل.س" / "50000.5" (حسب scale)
 * يرمي خطأ واضح إذا المدخل مش رقم صالح.
 */
export function toMinor(input, code) {
  const scale = scaleOf(code);
  const cleaned = normalizeDigits(input).replace(/[,\s]/g, '').replace(/[^\d.]/g, '');
  if (!cleaned || !/\d/.test(cleaned)) throw new InputError('المبلغ غير صالح');

  const num = Number(cleaned);
  if (!Number.isFinite(num) || num < 0) throw new InputError('المبلغ غير صالح');

  // نحذف أي فاصلة عشرية زيادة على الـ scale المحدد
  const truncated = scale === 0 ? Math.floor(num) : Math.floor(num * 10 ** scale) / 10 ** scale;
  const minor = Math.round(truncated * 10 ** scale);
  if (!Number.isSafeInteger(minor)) throw new InputError('المبلغ كبير جداً');
  return minor;
}

export function fromMinor(minor, code) {
  const scale = scaleOf(code);
  return minor / 10 ** scale;
}

export function formatMinor(minor, code = SHOP_CURRENCY, { withSymbol = true } = {}) {
  const { scale, symbol } = currencyOf(code) ?? CURRENCIES[SHOP_CURRENCY];
  const value = minor / 10 ** scale;
  const text = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: scale,
    maximumFractionDigits: scale,
  }).format(value);
  return withSymbol ? `${text} ${symbol}` : text;
}

/** تحويل مبلغ من عملة المصدر إلى عملة المتجر بنسبة سعر ثابت يضبطها الأدمن. */
export function convert(minor, fromCode, toCode, rate) {
  if (fromCode === toCode) return minor;
  const amount = fromMinor(minor, fromCode) * Number(rate);
  return toMinor(amount, toCode);
}

export class InputError extends Error {
  constructor(message) {
    super(message);
    this.name = 'InputError';
  }
}
