// نقطة الإقلاع: يشغّل السيرفر + البوتات معاً.
import { config, ensureDirs } from './config.js';
import { createServer } from './web/server.js';
import { createMainBot } from './bots/main.js';
import { createAdminBot } from './bots/admin.js';
import { registerSender } from './services/notify.js';
import * as payments from './services/payments.js';
import { getSecret } from './services/vault.js';
import { createLogger } from './utils/logger.js';

const log = createLogger('main');

ensureDirs();

/* --------------------------------- السيرفر -------------------------------- */
const app = createServer();
const server = app.listen(config.port, config.host, () => {
  log.info(`web dashboard on http://${config.host}:${config.port}`);
});

/* --------------------------------- البوتات -------------------------------- */
const adminBot = createAdminBot();
const mainBot = createMainBot();

// لو ما في بوت أدمن، الإشعارات بتروح على بوت العملاء للأدمنين
if (!adminBot && mainBot) {
  registerSender(async (text) => {
    for (const id of config.adminIds) {
      await mainBot.telegram.sendMessage(id, text, { parse_mode: 'HTML' }).catch(() => {});
    }
  });
  log.warn('main_bot_token مضبوط بدون admin_bot_token — الإشعارات رح تروح على بوت العملاء');
}

(async () => {
  try {
    if (adminBot) { await adminBot.launch(); log.info('admin bot running'); }
    if (mainBot) { await mainBot.launch(); log.info('main bot running'); }
    if (!adminBot && !mainBot) {
      log.error('ما في أي توكن بوت مضبوط. حطهم من اللوحة (التسجيل) أو في config/credentials.json');
    }
  } catch (err) {
    log.error('bot launch failed', { err: String(err.message) });
  }
})();

/* --------------------------- صيانة دورية --------------------------- */
const sweeper = setInterval(() => {
  try {
    payments.expireStale();
  } catch (err) {
    log.error('sweeper failed', { err: String(err.message) });
  }
}, 10 * 60 * 1000);
sweeper.unref?.();

/* ----------------------------- إغلاق مرتّب ----------------------------- */
let closing = false;
async function shutdown(signal) {
  if (closing) return;
  closing = true;
  log.info(`${signal} — إيقاف…`);
  clearInterval(sweeper);
  await Promise.allSettled([
    adminBot?.stop('SIGTERM'),
    mainBot?.stop('SIGTERM'),
    new Promise((r) => server.close(r)),
  ]);
  log.info('bye');
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('unhandledRejection', (err) => log.error('unhandledRejection', { err: String(err) }));

log.info('started', {
  prod: config.isProd,
  admins: config.adminIds.length,
  mainToken: Boolean(getSecret('main_bot_token')),
  adminToken: Boolean(getSecret('admin_bot_token')),
  shamSecret: Boolean(getSecret('sham_webhook_secret')),
});
