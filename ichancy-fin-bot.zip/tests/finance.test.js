// اختبارات المسار المالي: شحن، مطابقة صارمة، سحب، رفض وإرجاع، وأمانة السجل.
// التشغيل:  npm test
import { test, before, after, describe } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

process.env.DB_PATH = ':memory:';
process.env.ADMIN_IDS = '999';
process.env.LOG_LEVEL = 'error';

const { upsertUser } = await import('../src/services/users.js');
const ledger = await import('../src/services/ledger.js');
const payments = await import('../src/services/payments.js');
const withdrawals = await import('../src/services/withdrawals.js');
const gifts = await import('../src/services/gifts.js');
const settings = await import('../src/services/settings.js');
const shamcash = await import('../src/integrations/shamcash/index.js');
const vault = await import('../src/services/vault.js');
const { setCredential } = vault;
const { toMinor, formatMinor } = await import('../src/utils/money.js');

const U1 = 1001;
const U2 = 1002;
const SYP = 'SYP';

before(() => {
  upsertUser({ id: U1, first_name: 'عم', username: 'test1' });
  upsertUser({ id: U2, first_name: 'سارة', username: 'test2' });
  settings.set('payment_methods', [
    { id: 'sham', label: 'شام كاش', kind: 'wallet', currency: 'SYP', number: '0999', active: true, min: 0 },
    { id: 'usdt', label: 'USDT', kind: 'wallet', currency: 'USDT', number: 'TXYZ', active: true, min: 0 },
  ]);
  settings.set('deposit.auto_verify', true);
  settings.set('bonus.deposit_pct', 0);
});

describe('المبالغ', () => {
  test('يقرأ الأرقام العربية والفواصل', () => {
    assert.equal(toMinor('٥٠,٠٠٠', SYP), 50000);
    assert.equal(toMinor('12.50', 'USD'), 1250);
    assert.equal(formatMinor(50000, SYP), '50,000 ل.س');
  });

  test('يرفض المدخلات الفاشلة', () => {
    assert.throws(() => toMinor('abc', SYP));
    assert.throws(() => toMinor('', SYP));
  });
});

describe('السجل والأمانة', () => {
  test('الإضافة والخصم تشتغل', () => {
    ledger.credit(U1, 100000, { type: 'deposit' });
    assert.equal(ledger.balanceOf(U1), 100000);
    ledger.debit(U1, 30000, { type: 'withdraw_hold' });
    assert.equal(ledger.balanceOf(U1), 70000);
  });

  test('ما يسمح برصيد سالب', () => {
    assert.throws(() => ledger.debit(U1, 10_000_000, { type: 'adjust' }), /رصيد غير كافي/);
    assert.equal(ledger.balanceOf(U1), 70000);
  });

  test('كل حركات المستخدم مطابقة لرصيده', () => {
    assert.deepEqual(ledger.verifyIntegrity(), []);
  });
});

describe('الإيداع والمطابقة الصارمة', () => {
  const TX = 'TX-9001';

  test('ينشئ طلب إيداع', () => {
    const dep = payments.createIntent(U1, 'sham', '50000');
    assert.equal(dep.amount, 50000);
    assert.equal(dep.status, 'pending');
    payments.submitTx(dep.id, TX);
    assert.equal(payments.getDeposit(dep.id).tx_id, TX);
  });

  test('رقم عملية مستخدم من قبل = رفض', () => {
    const dep = payments.createIntent(U2, 'sham', '50000');
    assert.throws(() => payments.submitTx(dep.id, TX), /مستخدم من قبل/);
  });

  test('مبلغ مختلف مع نفس رقم العملية = ما بينشحن', () => {
    const before = ledger.balanceOf(U1);
    const out = payments.matchEvent({
      eventKey: 'e-wrong-amount', provider: 'test', payload: {},
      txId: TX, amount: 99999, currency: SYP,
    });
    assert.equal(out.result, 'unmatched');
    assert.equal(ledger.balanceOf(U1), before);
  });

  test('عملة مختلفة = ما بينشحن', () => {
    const out = payments.matchEvent({
      eventKey: 'e-wrong-currency', provider: 'test', payload: {},
      txId: TX, amount: 50000, currency: 'USD',
    });
    assert.equal(out.result, 'unmatched');
  });

  test('مطابقة تامة = شحن واحد', () => {
    const before = ledger.balanceOf(U1);
    const out = payments.matchEvent({
      eventKey: 'e-good', provider: 'test', payload: { tx: TX },
      txId: TX, amount: 50000, currency: SYP,
    });
    assert.equal(out.result, 'matched');
    assert.equal(ledger.balanceOf(U1), before + 50000);
  });

  test('نفس الحدث مرتين = ما بينشحن مرتين', () => {
    const before = ledger.balanceOf(U1);
    const out = payments.matchEvent({
      eventKey: 'e-good', provider: 'test', payload: {},
      txId: TX, amount: 50000, currency: SYP,
    });
    assert.equal(out.result, 'duplicate');
    assert.equal(ledger.balanceOf(U1), before);
  });

  test('حساب ما في طلب له ما بينشحن', () => {
    const out = payments.matchEvent({
      eventKey: 'e-ghost', provider: 'test', payload: {},
      txId: 'TX-NOPE', amount: 1000, currency: SYP,
    });
    assert.equal(out.result, 'unmatched');
  });
});

describe('البونص', () => {
  test('ينحسب على الشحن اليدوي', () => {
    settings.set('bonus.deposit_pct', 10);
    const dep = payments.createIntent(U2, 'sham', '10000');
    payments.submitTx(dep.id, 'TX-BONUS');
    const before = ledger.balanceOf(U2);
    payments.matchEvent({
      eventKey: 'e-bonus', provider: 'test', payload: {},
      txId: 'TX-BONUS', amount: 10000, currency: SYP,
    });
    assert.equal(ledger.balanceOf(U2), before + 11000);
    settings.set('bonus.deposit_pct', 0);
  });
});

describe('السحب', () => {
  test('المستخدم بدون رصيد ما بيقدر يسحب', () => {
    upsertUser({ id: 1003, first_name: 'فارغ' });
    assert.throws(
      () => withdrawals.request(1003, { methodId: 'sham', account: '0933123456', amount: '1000' }),
      /رصيد كافي/,
    );
  });

  test('الطلب بيحجز المبلغ فوراً', () => {
    const before = ledger.balanceOf(U1);
    const w = withdrawals.request(U1, { methodId: 'sham', account: '0933123456', amount: '20000' });
    assert.equal(ledger.balanceOf(U1), before - 20000);
    assert.equal(w.status, 'pending');
    assert.equal(w.net_amount, 20000);
  });

  test('الرفض بيرجّع المبلغ كامل', () => {
    const before = ledger.balanceOf(U1);
    const w = withdrawals.request(U1, { methodId: 'sham', account: '0933123456', amount: '5000' });
    const held = ledger.balanceOf(U1);
    assert.equal(held, before - 5000);
    withdrawals.reject(w.id, 999, 'test');
    assert.equal(ledger.balanceOf(U1), before);
  });

  test('ما بنقرر طلب مرتين', () => {
    const w = withdrawals.request(U1, { methodId: 'sham', account: '0933123456', amount: '1000' });
    withdrawals.approve(w.id, 999);
    assert.throws(() => withdrawals.approve(w.id, 999), /approved/);
    assert.throws(() => withdrawals.reject(w.id, 999), /approved/);
  });
});

describe('الإهداء', () => {
  test('التحويل بين مستخدمين ذرّي', () => {
    const a = ledger.balanceOf(U1);
    const b = ledger.balanceOf(U2);
    gifts.sendToId(U1, U2, '3000');
    assert.equal(ledger.balanceOf(U1), a - 3000);
    assert.equal(ledger.balanceOf(U2), b + 3000);
  });

  test('ما بنقدر نهدّي أكتر من الرصيد', () => {
    assert.throws(() => gifts.sendToId(1003, U1, '1000'), /رصيد غير كافي|غير موجود/);
  });
});

describe('توقيع شام كاش', () => {
  test('بدون سر بالإنتاج = رفض', () => {
    setCredential('sham_webhook_secret', 'super-secret-key');
    const raw = JSON.stringify({ tx_id: 'T1', amount: 100 });
    assert.equal(shamcash.verifySignature(raw, { 'x-sham-signature': 'sha256=deadbeef' }).ok, false);
  });

  test('توقيع صحيح = قبول', () => {
    const raw = JSON.stringify({ tx_id: 'T1', amount: 100 });
    const sig = crypto.createHmac('sha256', 'super-secret-key').update(raw).digest('hex');
    assert.equal(shamcash.verifySignature(raw, { 'x-sham-signature': `sha256=${sig}` }).ok, true);
  });

  test('Bearer صحيح = قبول', () => {
    const raw = '{}';
    assert.equal(shamcash.verifySignature(raw, { authorization: 'Bearer super-secret-key' }).ok, true);
  });

  test('توقيع غلط = 401', () => {
    const out = shamcash.handle('{}', { 'x-sham-signature': 'sha256=nope' });
    assert.equal(out.code, 401);
  });
});

describe('تطبيع الحمولة', () => {
  test('يقبل أسماء حقول مختلفة', () => {
    const a = shamcash.normalize({ transactionId: 'A1', value: 2500, currency: 'SYP' });
    assert.equal(a.txId, 'A1');
    assert.equal(a.amount, 2500);

    const b = shamcash.normalize({ data: { tx_id: 'B1', amount: '1000' } });
    assert.equal(b.txId, 'B1');
    assert.equal(b.amount, 1000);
  });

  test('يرفض حمولة بلا مبلغ', () => {
    assert.throws(() => shamcash.normalize({ tx_id: 'X' }), /مبلغ/);
  });
});

after(() => {
  const broken = ledger.verifyIntegrity();
  assert.deepEqual(broken, [], `سجل غير متوافق: ${JSON.stringify(broken)}`);
});
