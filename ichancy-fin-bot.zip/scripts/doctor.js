#!/usr/bin/env node
// فحص سريع: في شو ناقص، وهل السجل متوافق مع الأرصدة.
// التشغيل:  npm run doctor
import { config } from '../src/config.js';
import { getSecret, credentialList } from '../src/services/vault.js';
import * as ledger from '../src/services/ledger.js';
import * as users from '../src/services/users.js';
import { one } from '../src/db/index.js';

const g = (s) => `\x1b[32m✓\x1b[0m`;
const b = (s) => `\x1b[90m•\x1b[0m`;
const x = (s) => `\x1b[31m✗\x1b[0m`;

console.log('\n\x1b[1m▸ فحص المشروع\x1b[0m\n');

let problems = 0;

/* 1. البيئة */
console.log(`  ${config.adminIds.length ? g() : x('ما في ADMIN_IDS')} آيدي الأدمن: ${config.adminIds.join(', ') || '—'}`);
if (!config.adminIds.length) problems += 1;

const masterOk = Buffer.from(config.masterKey || '', 'base64').length === 32;
console.log(`  ${masterOk ? g() : x('MASTER_KEY ناقص')} مفتاح التشفير`);
if (!masterOk) problems += 1;

/* 2. التوكنات */
const mainT = getSecret('main_bot_token');
const adminT = getSecret('admin_bot_token');
const shamS = getSecret('sham_webhook_secret');

console.log(`  ${mainT ? g() : x('ناقص')} توكن بوت العملاء`);
if (!mainT) problems += 1;

console.log(`  ${adminT ? g() : b('اختياري')} توكن بوت الأدمن`);

const shamOk = Boolean(shamS);
console.log(`  ${shamOk ? g() : x('ناقص — الـ webhook رح يرفض كل شي')} سرّ توقيع شام كاش`);
if (!shamOk) problems += 1;

const wp = getSecret('web_password') || config.webPassword;
console.log(`  ${wp ? g() : x('ناقص')} كلمة سر اللوحة`);

/* 3. الأسرار المسجّلة */
const creds = credentialList();
if (creds.length) {
  console.log(`\n  الأسرار المسجّلة: ${creds.map((c) => c.name).join(', ')}`);
}

/* 4. سلامة السجل */
const broken = ledger.verifyIntegrity();
if (broken.length) {
  console.log(`\n  ${x(`${broken.length} مستخدم رصيدهم ما يطابق السجل`)}`);
  for (const b2 of broken.slice(0, 10)) {
    console.log(`     ${b2.id}: مخزّن ${b2.stored} / من السجل ${b2.from_ledger}`);
  }
  problems += 1;
} else {
  const users2 = one('SELECT COUNT(*) AS n FROM users').n;
  console.log(`\n  ${g()} الأرصدة متطابقة مع السجل (${users2} مستخدم)`);
}

/* 5. ملخّص */
const s = users.stats();
console.log(`
\x1b[90m▸ الحالة:\x1b[0m مستخدمين ${s.users} | حسابات آيسانسي ${s.accounts} | إجمالي الأرصدة ${s.liabilities.toLocaleString('en-US')} ل.س
`);

if (problems) {
  console.log(`\x1b[31m▸ في ${problems} مشكلة — شوف فوق.\x1b[0m\n`);
  process.exitCode = 1;
} else {
  console.log('\x1b[32m▸ كل شي تمام.\x1b[0m\n');
}
