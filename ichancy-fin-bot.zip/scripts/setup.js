#!/usr/bin/env node
// تهيئة أول مرة: يولّد المفاتيح السرّية ويكتب .env و config/credentials.json.
// التشغيل:  npm run setup
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { ROOT, CONFIG_DIR, ensureDirs } from '../src/config.js';

ensureDirs();

const envPath = path.join(ROOT, '.env');
const credPath = path.join(CONFIG_DIR, 'credentials.json');
const examplePath = path.join(ROOT, '.env.example');

const gen = (n) => crypto.randomBytes(n).toString('base64');

console.log('\n\x1b[36m▸ تهيئة المشروع\x1b[0m\n');

/* ------------------------------- .env ------------------------------- */
if (fs.existsSync(envPath)) {
  console.log('  \x1b[90m•\x1b[0m .env موجود — ما رح نلمسه');
} else {
  const values = {
    NODE_ENV: 'development',
    PORT: '3000',
    ADMIN_IDS: '',           // ← حط آيدي تيليغرام تبعك، مفصولة بفاصلة
    MASTER_KEY: gen(32),     // 32 بايت base64 — هاد بيفكّ تشفير التوكنات، خليه سري
    SESSION_SECRET: gen(32),
    WEB_PASSWORD: gen(12),
    SHAM_WEBHOOK_SECRET: gen(32),
    SHAM_RECEIVER_NUMBERS: '',
    PUBLIC_URL: '',
    ICHANCY_DRIVER: 'mock',
    LOG_LEVEL: 'info',
  };
  const body = Object.entries(values)
    .map(([k, v]) => `${k}=${v}`)
    .join('\n');
  fs.writeFileSync(envPath, body, { mode: 0o600 });
  console.log(`  \x1b[32m✓\x1b[0m أنشأنا .env  \x1b[90m(بصلاحيات 600)\x1b[0m`);
}

/* ------------------------ config/credentials.json ------------------------ */
if (fs.existsSync(credPath)) {
  console.log('  \x1b[90m•\x1b[0m config/credentials.json موجود — ما رح نلمسه');
} else {
  const creds = {
    main_bot_token: '',
    admin_bot_token: '',
    sham_webhook_secret: '',
    web_password: '',
  };
  fs.writeFileSync(credPath, JSON.stringify(creds, null, 2), { mode: 0o600 });
  console.log('  \x1b[32m✓\x1b[0m أنشأنا config/credentials.json');
}

/* ------------------------------ .gitignore ------------------------------ */
const giPath = path.join(ROOT, '.gitignore');
if (!fs.existsSync(giPath)) {
  fs.writeFileSync(giPath, ['node_modules/', '.env', 'data/', 'logs/', '*.png', 'config/credentials.json', ''].join('\n'));
  console.log('  \x1b[32m✓\x1b[0m أنشأنا .gitignore');
}

if (!fs.existsSync(examplePath)) {
  const sample = fs.readFileSync(envPath, 'utf8')
    .replace(/^(MASTER_KEY|SESSION_SECRET|WEB_PASSWORD|SHAM_WEBHOOK_SECRET)=.*$/gm, '$1=');
  fs.writeFileSync(examplePath, sample);
}

console.log(`
\x1b[33m▸ المطلوب منك الحين:\x1b[0m

  1. افتح \`.env\` وحط آيدي تيليغرام تبعك:
       \x1b[1mADMIN_IDS=123456789\x1b[0m

  2. من \x1b[1m@BotFather\x1b[0m أنشئ بوتّين وسجّل توكناتهم في \`config/credentials.json\`:
       • \x1b[1mmain_bot_token\x1b[0m  — بوت العملاء
       • \x1b[1madmin_bot_token\x1b[0m — بوت الأدمن (اختياري بس منصوح فيه)

  3. شغّل:
       \x1b[1mnpm start\x1b[0m

  4. افتح \x1b[1mhttp://localhost:3000\x1b[0m وسجّل دخولك.

\x1b[90mملاحظة: التوكنات بتقرأ من config/credentials.json أولاً، وبعدها من متغيّرات البيئة.
ما في أي توكن جاهز مدمج بالنظام — حط توكناتك انت.\x1b[0m
`);
