#!/usr/bin/env node
// يمسح قاعدة البيانات ويبلّش من جديد. كل الأرصدة والسجلات بتروح — استخدم بحذر.
import fs from 'node:fs';
import readline from 'node:readline/promises';
import { DB_PATH } from '../src/config.js';

if (!fs.existsSync(DB_PATH)) {
  console.log('ما في قاعدة بيانات أصلاً.');
  process.exit(0);
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const { answer } = await rl.question(
  `\x1b[31mرح نمسح ${DB_PATH} وكل الأرصدة والسجلات.\x1b[0m اكتب "نعم" للتأكيد: `,
);
rl.close();

if (answer.trim() !== 'نعم') {
  console.log('أُلغي.');
  process.exit(0);
}

for (const suffix of ['', '-wal', '-shm']) {
  const f = `${DB_PATH}${suffix}`;
  if (fs.existsSync(f)) fs.unlinkSync(f);
}
console.log('\x1b[32m✓ انمسحت. التشغيل الجاي بيعيد إنشاء كلشي.\x1b[0m');
